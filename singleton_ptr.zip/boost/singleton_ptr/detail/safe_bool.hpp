
//////////////////////////////////////////////////////////////////////////////
// safe_bool.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.10.2005
// Purpose: Encapsulate safe conversion to type which is testable in
//          conditional statements using CRTP.  Type must define the member
//          function 'exists (  ) const', which returns some type which is
//          valid to use in the context of a condition (most likely bool).
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SAFE_BOOL_INCLUDED_
#define BOOST_SAFE_BOOL_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

namespace boost
{
    template < typename Type >
    class safe_bool
	{
    private:
        void f (  ) {  }

    public:
        typedef void ( safe_bool < Type > :: *bool_type )(  );

        // returns pointer to a member function, which can be tested in
        // conditional expressions but does not implicitly convert to an
        // integer type
        operator bool_type const (  )
        {
            return static_cast < Type * const > ( this )->
                exists (  ) ? &safe_bool < Type >::f : 0;
        }
	};
}

#endif//BOOST_SAFE_BOOL_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
