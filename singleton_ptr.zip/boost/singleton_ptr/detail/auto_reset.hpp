
//////////////////////////////////////////////////////////////////////////////
// auto_reset.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.17.2005
// Purpose: Provide a mechanism to automatically reset some variable when an
//          auto_reset instance is destroyed.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_AUTO_RESET_INCLUDED_
#define BOOST_AUTO_RESET_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

namespace boost { namespace detail {
{
    // Type must have a non-throwing assignment operator
    template < typename Type >
    struct auto_reset
    {
        Type & var; Type val;
        auto_reset ( Type & var ) :
            var ( var ), val ( var ) {  }
        auto_reset ( Type & var, Type val ) :
            var ( var ), val ( val ) {  }
        ~ auto_reset (  ) { var = val; }
    };
} }

#endif//BOOST_AUTO_RESET_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revised: <never>
//
//////////////////////////////////////////////////////////////////////////////
