
//////////////////////////////////////////////////////////////////////////////
// dynamic_type_tag.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.17.2005
// Purpose: Provide a tag which can be used as the first argument passed to
//          create to specify the concrete type to construct.  Only valid
//          for creators or factories that support it.  Generally, this means
//          only creators or factories that allocate memory dynamically.
//          This feature is only available on compilers that support partial
//          template specialization.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_DYNAMIC_TYPE_TAG_INCLUDED_
#define BOOST_SINGLETON_PTR_DYNAMIC_TYPE_TAG_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

namespace boost { namespace singleton
{
    template < typename Type >
    struct dynamic_type_tag
    {
        typedef Type type;
        static dynamic_type_tag < Type > tag;
    };

    template < typename Type >
    dynamic_type_tag < Type > dynamic_type_tag < Type >::tag;
} }

#endif//BOOST_SINGLETON_PTR_DYNAMIC_TYPE_TAG_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
