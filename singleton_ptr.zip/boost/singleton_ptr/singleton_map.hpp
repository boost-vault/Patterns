
//////////////////////////////////////////////////////////////////////////////
// singleton_map.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 10.05.2005
// Purpose: Provide default associative container policy.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_MAP_INCLUDED_
#define BOOST_SINGLETON_PTR_MAP_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <map>

namespace boost { namespace singleton
{
    struct map
    {
        template < typename Key, typename Type >
        struct pair_assoc_container
        {
            typedef ::std::map < Key, Type > type;
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_MAP_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
