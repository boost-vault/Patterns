
//////////////////////////////////////////////////////////////////////////////
// thread_safe_storage.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.12.2005
// Purpose: Extend collective_storage to provide thread safe COFU
//          (Construct On First Use) and thread safe unloading at
//          process termination.  Requires linking with Boost Threads
//          library (see http://www.boost.org/doc/html/threads.html
//          for details).  This method of locking is only safe if the
//          instance is not shared between multiple processes.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_THREAD_SAFE_STORAGE_INCLUDED_
#define BOOST_SINGLETON_PTR_THREAD_SAFE_STORAGE_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/thread/mutex.hpp>
#include <boost/singleton_ptr/collective_storage.hpp>

namespace boost
{
    namespace singleton
    {
        namespace detail
        {
            // track whether static mutex exists or has been destroyed
            static bool & mutex_exists (  )
            {
                static bool b = false;
                return b;
            }

            // by using a static instance of this
            struct mutex_lifetime_tracker
            {
                  mutex_lifetime_tracker (  ) { mutex_exists (  ) = true;  }
                ~ mutex_lifetime_tracker (  ) { mutex_exists (  ) = false; }
            };

            ::boost::mutex & the_mutex (  )
            {
                // static variables are destroyed in reverse order of creation
                // as a result lifetime_tracker works effectively
                static mutex_lifetime_tracker tracker;
                static ::boost::mutex mux;
                return mux;
            }

            // we must force the mutex to be created before main is entered,
            // to ensure that it is initialized safely in a single threaded
            // context
            struct ensure_mutex_creation_before_main
            {
                ensure_mutex_creation_before_main (  )
                {
                    ::boost::mutex & mux = the_mutex (  );
                }

            } force_mutex_creation;
        }

        // Requires that process be single threaded until main
        // has been entered (so that mutex initialization is safe)
        struct thread_safe_atomic_call
        {
            template
            <
                typename Name,
                typename Type
            >
            struct atomic_call
            {
                // serialize function access
                static void invoke ( void ( *func )(  ) )
                {
                    if ( ::boost::singleton::detail::mutex_exists (  ) )
                    {
                        // lock the operation
                        ::boost::mutex::scoped_lock guard (
                            ::boost::singleton::detail::the_mutex (  ) );
                        ( void ) guard; // disable unused variable warnings

                        func (  );
                    }
                    else
                    {
                        // if the mutex no longer exists, the last thread
                        // must be exiting so we don't need it anyhow
                        func (  );
                    }
                }
            };
        };

        // thread_safe_storage extends collective_storage
        // by locking all operations, ensuring that
        // calls are actually atomic.
        typedef ::boost::singleton::collective_storage_ex
        <
            simple_accessor,
            thread_safe_atomic_call

        > thread_safe_storage;
    }
}

#endif//BOOST_SINGLETON_PTR_THREAD_SAFE_STORAGE_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
