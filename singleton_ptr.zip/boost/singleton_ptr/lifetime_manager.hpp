
//////////////////////////////////////////////////////////////////////////////
// lifetime_manager.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.16.2005
// Purpose: Provide a class which manages the lifetimes of other resources.
//          Resources are destroyed first by reverse order of longevity, and
//          second by reverse order of creation.  Default longevity is zero.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_LIFETIME_MANAGER_INCLUDED_
#define BOOST_SINGLETON_PTR_LIFETIME_MANAGER_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <memory>
#include <cstddef>

#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>

#include <boost/singleton_ptr/config.hpp>
#include <boost/singleton_ptr/exceptions.hpp>

namespace boost { namespace singleton
{
    // Use a standard allocator to manage memory for
    // the priority queue of nodes.
    template < typename Allocator >
    class lifetime_manager_ex
    {
    private:
        // base type for all nodes which can be registered for destruction
        struct node_base
        {
            // remember size of concrete derived type
            ::std::size_t full_size;
            // used for sorting
            int longevity;
            unsigned int creation_index;
            node_base * next;

            node_base ( ::std::size_t full_size,
                        unsigned int longevity,
                        unsigned int counter )

                : full_size ( full_size )
                , longevity ( longevity )
                , creation_index ( counter )
                , next ( 0 )
            {
            }

            // nodes are destroyed through a pointer to base
            virtual ~ node_base (  )
            {
            }

            // check sorting criteria
            bool destroy_after ( const node_base & rhs ) const
            {
                return longevity > rhs.longevity ||
                    ( longevity == rhs.longevity &&
                    creation_index < rhs.creation_index );
            }
        };

        // concrete node type
        template < typename Type >
        struct node : public node_base
        {
            // own the registered resource directly
            Type val;

            // default ctor, creates the resource instance
            node ( unsigned int longevity, unsigned int counter )
                : node_base ( sizeof ( node < Type > ),
                                longevity, counter )
            {
                // default ctor for val is called automatically
            }

            // generate node constructors which
            // pass params to the resource's constructor
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            node ( unsigned int longevity, unsigned int counter,            \
                BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p ) )             \
                : node_base ( longevity, counter )                          \
                , val ( BOOST_PP_ENUM_PARAMS(n, p) )                        \
            {                                                               \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // node is destroyed through a pointer to base
            virtual ~ node (  )
            {
            }
        };

        // helper struct which automatically frees memory allocated
        // for a resource if construction of the resource fails
        struct free_on_error
        {
        private:
            typename Allocator::rebind < char > ::other * alloc_ptr;
            void * mem;
            ::std::size_t size;
            bool release;

        public:
            free_on_error ( typename Allocator::rebind < char >::other
                            * alloc_ptr, void * mem, ::std::size_t size )

                : alloc_ptr ( alloc_ptr )
                , mem ( mem )
                , size ( size )
                , release ( true )
            {
            }

            void discard (  )
            {
                release = false;
            }

            ~ free_on_error (  )
            {
                if ( release ) alloc_ptr->deallocate (
                    reinterpret_cast < char * > ( mem ), size );
            }
        };

        // we must use an allocator based on char because we will
        // be allocating different objects of different sizes by
        // passing the required size to the allocate function.
        typename Allocator::rebind < char >::other allocator;
        node_base * front;
        unsigned int counter;

        // insert a node in the priority queue
        void insert ( node_base * newnode )
        {
            if ( !front || front->destroy_after ( *newnode ) )
            {
                newnode->next = front;
                front = newnode;
            }
            else
            {
                node_base * cur = front;
                while ( true )
                {
                    node_base * next = cur->next;
                    if ( !next || next->destroy_after ( *newnode ) )
                    {
                        newnode->next = next;
                        cur->next = newnode;
                        break;
                    }
                    cur = next;
                }
            }
        }

    public:
        // Create a resource of type Type and register it for destruction.
        // Resource automatically is given a longevity of zero.
        // Can take any number of params, which are forwarded to Type's
        // constructor.
        template < typename Type >
        Type * create_and_register (  )
        {
            void * mem = allocator.allocate ( sizeof ( node < Type > ) );
            free_on_error foe ( &allocator, mem, sizeof ( node < Type > ) );
            node < Type > * newnode =
                new ( mem ) node < Type > ( 0, counter );
            foe.discard (  );
            ++counter;
            insert ( newnode );
            return &newnode->val;
        }

        // generate create_and_register functions
        // which pass params to Type's constructor
        #define BOOST_PP_LOCAL_LIMITS (1,                                   \
            BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
        #define BOOST_PP_LOCAL_MACRO(n)                                     \
        template < typename Type, BOOST_PP_ENUM_PARAMS(n, typename P) >     \
        Type * create_and_register (                                        \
            BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p ) )                 \
        {                                                                   \
            void * mem = allocator.allocate ( sizeof ( node < Type > ) );   \
            free_on_error foe ( &allocator, mem, sizeof ( node < Type > ) );\
            node < Type > * newnode =                                       \
                new ( mem ) node < Type > ( 0, counter,                     \
                BOOST_PP_ENUM_PARAMS(n, p) );                               \
            foe.discard (  );                                               \
            ++counter;                                                      \
            insert ( newnode );                                             \
            return &newnode->val;                                           \
        }
        #include BOOST_PP_LOCAL_ITERATE()

        // Create a resource of type Type and register it for destruction.
        // Resource uses the provided longevity to control its relative order
        // of destruction.  Can take any number of params after the longevity,
        // which are forwarded to Type's constructor.
        template < typename Type >
        Type * create_and_register_with_longevity ( unsigned int longevity )
        {
            void * mem = allocator.allocate ( sizeof ( node < Type > ) );
            free_on_error foe ( &allocator, mem, sizeof ( node < Type > ) );
            node < Type > * newnode =
                new ( mem ) node < Type > ( longevity, counter );
            foe.discard (  );
            ++counter;
            insert ( newnode );
            return &newnode->val;
        }

        // generate create_and_register_with_longevity functions
        // which pass params to Type's constructor
        #define BOOST_PP_LOCAL_LIMITS (1,                                   \
            BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
        #define BOOST_PP_LOCAL_MACRO(n)                                     \
        template < typename Type, BOOST_PP_ENUM_PARAMS(n, typename P) >     \
        Type * create_and_register_with_longevity ( unsigned int longevity, \
            BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p ) )                 \
        {                                                                   \
            void * mem = allocator.allocate ( sizeof ( node < Type > ) );   \
            free_on_error foe ( &allocator, mem, sizeof ( node < Type > ) );\
            node < Type > * newnode =                                       \
                new ( mem ) node < Type > ( longevity, counter,             \
                BOOST_PP_ENUM_PARAMS(n, p) );                               \
            foe.discard (  );                                               \
            ++counter;                                                      \
            insert ( newnode );                                             \
            return &newnode->val;                                           \
        }
        #include BOOST_PP_LOCAL_ITERATE()

        // Pops one resource from the priority queue,
        // does nothing if queue is empty.
        void destroy_next (  )
        {
            if ( front )
            {
                node_base * removed = front;
                front = front->next;
                ::std::size_t full_size = removed->full_size;
                removed->~node_base (  );
                allocator.deallocate ( reinterpret_cast < char * >
                    ( removed ), full_size );
            }
        }

        // Pops all resources, one by one, from the queue.
        // Adding a resource to the queue from the destructor
        // of a resource already in the queue behaves naturally
        // and correctly.
        void destroy_all (  )
        {
            while ( front ) destroy_next (  );
        }

        // Initialize the priority queue to empty.
        lifetime_manager_ex (  )
            : front ( 0 )
            , counter ( 0 )
        {
        }

        // Destroy all registered resources.
        ~ lifetime_manager_ex (  )
        {
            destroy_all (  );
        }
    };

    // default lifetime manager uses the process-local heap
    typedef lifetime_manager_ex
    <
        ::std::allocator < char >
    
    > lifetime_manager;

} }

#endif//BOOST_SINGLETON_PTR_LIFETIME_MANAGER_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
