
//////////////////////////////////////////////////////////////////////////////
// scoped_destroyer.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.16.2005
// Purpose: Destroy singleton instance when scoped_destroyer goes out of scope.
//          Can also be registered with a lifetime_manager to schedule a
//          singleton for destruction.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_SCOPED_DESTROYER_INCLUDED_
#define BOOST_SINGLETON_PTR_SCOPED_DESTROYER_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

namespace boost
{
    namespace singleton
    {
        template < typename SingletonPointer >
        struct scoped_destroyer
        {
        private:
            SingletonPointer ptr;

        public:
            ~ scoped_destroyer (  )
            {
                ptr.destroy (  );
            }
        };
    }
}

#endif//BOOST_SINGLETON_PTR_SCOPED_DESTROYER_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
