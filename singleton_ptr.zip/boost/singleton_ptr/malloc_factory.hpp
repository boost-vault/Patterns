
//////////////////////////////////////////////////////////////////////////////
// malloc_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which uses
//          malloc and free to manage memory for the singleton instance.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_MALLOC_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_MALLOC_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <limits>
#include <cstdlib>
#include <cstddef>

#include <boost/config.hpp>
#include <boost/singleton_ptr/allocator_factory.hpp>

namespace boost { namespace singleton
{
    // yeah, yeah, I know...
    // I should have called it the 'mallocator' ;^)
    template < typename Type >
    struct malloc_allocator
    {
        // typedefs
        typedef Type value_type;
        typedef value_type * pointer;
        typedef const value_type * const_pointer;
        typedef value_type & reference;
        typedef const value_type & const_reference;
        typedef ::std::size_t size_type;
        typedef ::std::ptrdiff_t difference_type;

        // rebind
        template < typename Other >
        struct rebind
        {
            typedef malloc_allocator < Other > other;
        };

        malloc_allocator (  ) {  }

        // copy construct from any allocator in allocator family
        template < typename Other >
        explicit malloc_allocator ( const malloc_allocator < Other > & ) {  }

        pointer address ( reference r ) { return &r; }
        const_pointer address ( const_reference r ) { return &r; }

        // allocate with malloc
        pointer allocate ( size_type instances, const_pointer = 0 )
        {
            using namespace std;
            return reinterpret_cast < pointer > (
                malloc ( instances * sizeof ( Type ) ) );
        }

        // deallocate with free, make deallocating null a safe no-op
        void deallocate ( pointer ptr, size_type )
        { 
            using namespace std;
            if ( ptr ) free ( ptr );
        }

        size_type max_size (  ) const
        { 
            return ::std::numeric_limits < size_type >::max (  )
                / sizeof ( Type );
        }

        void construct ( pointer ptr, const Type & t )
        {
            new ( ptr ) Type ( t );
        }

        void destroy ( pointer ptr )
        {
            ptr->~Type (  );
        }

        bool operator == ( const malloc_allocator & ) { return true; }
        bool operator != ( const malloc_allocator & ) { return false; }
    };

    // choose default malloc_factory implementation based
    // on detected exception handling support
    #ifdef BOOST_NO_EXCEPTIONS
        typedef ::boost::singleton::allocator_factory_ex
        <
            ::boost::singleton::malloc_allocator < char >, true

        > malloc_factory;
    #else
        typedef ::boost::singleton::allocator_factory_ex
        <
            ::boost::singleton::malloc_allocator < char >, false

        > malloc_factory;
    #endif

} }

#endif//BOOST_SINGLETON_PTR_MALLOC_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
