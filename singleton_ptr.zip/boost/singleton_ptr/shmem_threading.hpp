
////////////////////////////////////////////////////////////////////////////////
// shmem_threading.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.13.2005
// Purpose: Specialization of multi_threaded_ex designed to work in
//          conjunction with the shmem_storage policy.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_SHMEM_THREADING_INCLUDED_
#define BOOST_SINGLETON_PTR_SHMEM_THREADING_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/singleton_ptr/shmem_storage.hpp>
#include <boost/singleton_ptr/multi_threaded_ex.hpp>

namespace boost { namespace singleton
{
    typedef ::boost::singleton::multi_threaded_ex
    <
        ::boost::singleton::shmem_mutex

    > shmem_threading;
} }

#endif//BOOST_SINGLETON_PTR_SHMEM_THREADING_INCLUDED_

////////////////////////////////////////////////////////////////////////////////
// Revision history:
//
////////////////////////////////////////////////////////////////////////////////
