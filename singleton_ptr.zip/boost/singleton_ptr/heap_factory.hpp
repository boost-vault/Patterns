
//////////////////////////////////////////////////////////////////////////////
// heap_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which uses
//          new and delete to create and destroy the singleton instance.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_HEAP_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_HEAP_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>

#include <boost/config.hpp>
#include <boost/assert.hpp>
#include <boost/static_assert.hpp>

// the following are required for generation of create functions
#include <boost/preprocessor/punctuation/comma.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/dynamic_type_tag.hpp>

namespace boost { namespace singleton
{
    // general case, can throw
    template < bool NoThrow >
    struct heap_factory_ex
    {
        // require use of NoThrow variant if exceptions are not supported
        #ifdef BOOST_NO_EXCEPTIONS
            BOOST_STATIC_ASSERT ( !"Exceptions are not enabled." );
        #endif

        template
        <
            typename Name,
            typename Type
        >
        struct factory
        {
        public:
            // required typedefs
            typedef Type & reference;
            typedef Type * pointer;
            typedef Type * const const_pointer;

            // return result of new
            pointer create (  )
            {
                return new Type (  );
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                return new Type ( BOOST_PP_ENUM_PARAMS(n, p) );             \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // overload taking a dynamic_type_tag as a first parameter
            template < typename Tag >
            pointer create ( const ::boost::singleton::dynamic_type_tag
                < Tag > & )
            {
                // if there is no implicit conversion to pointer (to base)
                // then this line will not compile
                return new Tag (  );
            }

            // generate create function overloads taking
            // a dynamic_type_tag as a first parameter
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < typename Tag, BOOST_PP_ENUM_PARAMS(n, typename P) >  \
            pointer create ( const ::boost::singleton::dynamic_type_tag     \
                < Tag > & BOOST_PP_COMMA()                                  \
                BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )              \
            {                                                               \
                return new Tag ( BOOST_PP_ENUM_PARAMS(n, p) );              \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // destroy instance
            void destroy ( pointer ptr )
            {
                BOOST_ASSERT ( ptr );
                delete ptr;
            }
        };
    };

    // new cannot throw, create returns null on memory allocation failure
    // note that operation can still potentially throw if exceptions are
    // enabled and Type has a constructor that can throw
    template <  >
    struct heap_factory_ex < true >
    {
        template < typename Type >
        struct factory
        {
        public:
            // required typedefs
            typedef Type & reference;
            typedef Type * pointer;
            typedef Type * const const_pointer;

            // return result of nothrow new
            pointer create (  )
            {
                return new ( ::std::nothrow ) Type (  );
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                return new ( ::std::nothrow )                               \
                    Type ( BOOST_PP_ENUM_PARAMS(n, p) );                    \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // overload taking a dynamic_type_tag as a first parameter
            template < typename Tag >
            pointer create ( const ::boost::singleton::dynamic_type_tag
                < Tag > & )
            {
                // if there is no implicit conversion to pointer (to base)
                // then this line will not compile
                return new ( ::std::nothrow ) Tag (  );
            }

            // generate create function overloads taking
            // a dynamic_type_tag as a first parameter
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < typename Tag, BOOST_PP_ENUM_PARAMS(n, typename P) >  \
            pointer create ( const ::boost::singleton::dynamic_type_tag     \
                < Tag > & BOOST_PP_COMMA()                                  \
                BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )              \
            {                                                               \
                return new ( ::std::nothrow )                               \
                    Tag ( BOOST_PP_ENUM_PARAMS(n, p) );                     \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // destroy instance
            void destroy ( pointer ptr )
            {
                BOOST_ASSERT ( ptr );
                delete ptr;
            }
        };
    };

    // choose default heap_factory implementation based
    // on detected exception handling support
    #ifdef BOOST_NO_EXCEPTIONS
        typedef heap_factory_ex < true > heap_factory;
    #else
        typedef heap_factory_ex < false > heap_factory;
    #endif
} }

#endif//BOOST_SINGLETON_PTR_HEAP_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
