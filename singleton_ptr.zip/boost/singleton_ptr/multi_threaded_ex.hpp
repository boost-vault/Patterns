
//////////////////////////////////////////////////////////////////////////////
// multi_threaded_ex.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.08.2005
// Purpose: Basis for a multi threaded threading policy, requires
//          that the type of mutex and lock be supplied by the user.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_MULTI_THREADED_EX_INCLUDED_
#define BOOST_SINGLETON_PTR_MULTI_THREADED_EX_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <boost/aligned_storage.hpp>

namespace boost { namespace singleton
{
    // use this to build a mutex type usable by multi_threaded_ex
    // from existing mutex and lock types
    template
    <
        typename Mutex,
        typename ReadLock = Mutex::scoped_lock,
        typename WriteLock = Mutex::scoped_lock
    >
    struct mutex_wrapper
    {
        template
        <
            typename Name,
            typename Type
        >
        struct mutex
        {
            typedef Mutex mutex_type;
            typedef ReadLock read_lock_type;
            typedef WriteLock write_lock_type;
        };
    };

    template
    <
        typename Mutex
    >
    struct multi_threaded_ex
    {
        template
        <
            typename Name,
            typename Type,
            typename Creator
        >
        struct threading
        {
        public:
            // internal policy types
            typedef Creator creator_type;

            // syncronization primitives
            typedef typename Mutex::mutex < Name, Type > mutex_wrapper;
            typedef typename mutex_wrapper::mutex_type mutex_type;
            typedef typename mutex_wrapper::read_lock_type read_lock_type;
            typedef typename mutex_wrapper::write_lock_type write_lock_type;

            // action function signature used for callbacks during
            // pointer creation and pointer dereferencing
            typedef bool ( *action_type )( creator_type * );

            typedef threading < Name, Type, Creator > threading_type;

            // inner pointer types
            typedef typename
                creator_type::reference     inner_reference;
            typedef typename
                creator_type::pointer       inner_pointer;
            typedef typename
                creator_type::const_pointer inner_const_pointer;

        private:
            // member vars
            mutex_type mux;
            volatile creator_type creator;

        public:
            // Reference is considered to be a dereferenced pointer.
            // Top most reference type will hold an exclusive lock.
            struct reference
            {
            private:
                // member vars
                inner_reference inner;

            public:
                // must be provided with a pointer to the threading
                // policy and the actions to invoke upon creation and
                // dereferencing of the pointer
                reference ( threading_type * threading_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : inner ( threading_ptr->get_creator (  ),
                                on_creation, on_dereference ) )
                {
                }

                operator Type & (  )
                {
                    return inner;
                }

                operator const Type & (  ) const
                {
                    return inner;
                }
            };

            // forward declaration
            struct const_pointer;

            // The below is a bit complicated, because an intermediate pointer
            // type must be returned to perform locking, but as that pointer
            // type is returned by value it needs to make sure to share the
            // lock among its copies and do reference counting.  This
            // reference count and lock are maintained by the original pointer
            // being dereferenced (lock is created in place using
            // aligned_storage)
            struct pointer
            {
            private:
                // inner pointer type which performs locking
                struct locked_pointer
                {
                private:
                    // member vars
                    write_lock_type & lock;
                    const inner_pointer & ptr;
                    int & refcount;

                public:
                    // construct from outer pointer
                    locked_pointer ( write_lock_type & lock,
                                     const inner_pointer & ptr,
                                     int & refcount )

                        : lock ( lock )
                        , ptr ( ptr )
                        , refcount ( refcount )
                    {
                        ++refcount;
                    }

                    // copy construct
                    locked_pointer ( const locked_pointer & other )

                        : lock ( other.lock )
                        , ptr ( other.ptr )
                        , refcount ( other.refcount )
                    {
                        ++refcount;
                    }

                    ~ locked_pointer (  )
                    {
                        // when locked_pointer refcount drops to zero...
                        if ( !--refcount )
                        {
                            // release the lock
                            lock.~write_lock_type (  );
                        }
                    }

                    const inner_pointer & operator -> (  )
                    {
                        return ptr;
                    }
                };

                // member vars
                threading_type * threading_ptr;
                inner_pointer inner;
                mutable int refcount;
                mutable typename ::boost::aligned_storage
                    < sizeof ( write_lock_type ) >::type lock_storage;

            public:
                // must be provided with a pointer to the threading
                // policy and the actions to invoke upon creation and
                // dereferencing of the pointer
                pointer ( threading_type * threading_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : threading_ptr ( threading_ptr )
                    // const cast away volatile is safe here,
                    // because external pointer type holds a lock
                    // during initialization
                    , inner ( const_cast < creator_type * > (
                              threading_ptr->get_creator (  ) ),
                                on_creation, on_dereference )
                    , refcount ( 0 )
                {
                }

                locked_pointer operator -> (  ) const
                {
                    // get pointer to lock storage
                    write_lock_type * plock = reinterpret_cast
                        < write_lock_type * > ( &lock_storage );

                    // create the lock
                    new ( plock ) write_lock_type (
                        threading_ptr->get_mutex (  ) );

                    return locked_pointer ( *plock, inner, refcount );
                }

                // allow access to threading_ptr for implicit conversion
                friend struct const_pointer;
            };

            struct const_pointer
            {
            private:
                // inner pointer type which performs locking
                struct locked_pointer
                {
                private:
                    // member vars
                    read_lock_type & lock;
                    const inner_const_pointer & ptr;
                    int & refcount;

                public:
                    // construct from outer pointer
                    locked_pointer ( read_lock_type & lock,
                                     const inner_const_pointer & ptr,
                                     int & refcount )

                        : lock ( lock )
                        , ptr ( ptr )
                        , refcount ( refcount )
                    {
                        ++refcount;
                    }

                    // copy construct
                    locked_pointer ( const locked_pointer & other )

                        : lock ( other.lock )
                        , ptr ( other.ptr )
                        , refcount ( other.refcount )
                    {
                        ++refcount;
                    }

                    ~ locked_pointer (  )
                    {
                        // when locked_pointer refcount drops to zero...
                        if ( !--refcount )
                        {
                            // release the lock
                            lock.~read_lock_type (  );
                        }
                    }

                    const inner_const_pointer & operator -> (  )
                    {
                        return ptr;
                    }
                };

                // member vars
                threading_type * threading_ptr;
                inner_const_pointer inner;
                mutable int refcount;
                typename ::boost::aligned_storage
                    < sizeof ( read_lock_type ) >::type lock_storage;

            public:
                // must be provided with a pointer to the threading
                // policy and the actions to invoke upon creation and
                // dereferencing of the pointer
                const_pointer ( threading_type * const threading_ptr,
                                action_type on_creation,
                                action_type on_dereference )

                    : threading_ptr ( threading_ptr )
                    , inner ( threading_ptr->get_raw_creator (  ),
                                on_creation, on_dereference ) )
                {
                }

                // implicitly constructable from pointer
                const_pointer ( const pointer & ptr )

                    : threading_ptr ( ptr.threading_ptr )
                    , inner ( ptr.threading_ptr->get_raw_creator (  ),
                                ptr.on_creation, ptr->on_dereference ) )

                {
                }

                locked_pointer operator -> (  ) const
                {
                    // get pointer to lock storage
                    read_lock_type * plock = reinterpret_cast
                        < read_lock_type * > ( &lock_storage );

                    // create the lock
                    new ( plock ) read_lock_type (
                        threading_ptr->get_mutex (  ) );

                    return locked_pointer ( *plock, inner, refcount );
                }
            };

            // get pointer to creator
            volatile creator_type * get_creator (  ) volatile
            {
                return &creator;
            }

            // get const pointer to creator
            volatile creator_type * const get_creator (  ) const volatile
            {
                return &creator;
            }

            // access the mutex
            mutex_type & get_mutex (  ) volatile
            {
                // I think this is safe
                return const_cast < mutex_type & > ( mux );
            }
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_MULTI_THREADED_EX_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
