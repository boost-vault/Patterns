
//////////////////////////////////////////////////////////////////////////////
// actions.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.16.2005
// Purpose: Policies which provide automated behavior for use by
//          singleton_ptr creator policies.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_ACTIONS_INCLUDED_
#define BOOST_SINGLETON_PTR_ACTIONS_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/assert.hpp>
#include <boost/singleton_ptr/exceptions.hpp>

namespace boost { namespace singleton
{
    // action which does nothing and allows
    // the operation to continue normally
    struct ignore_action
    {
        template < typename CreatorPointer >
        static bool invoke ( CreatorPointer )
        {
            return true;
        }
    };

    // action which makes the current operation a no-op
    // if operation cannot immediately return normally an exception will
    // be thrown.  this is most likely to happen in a constructor or
    // any operation which does not return void.
    struct block_action
    {
        template < typename CreatorPointer >
        static bool invoke ( CreatorPointer )
        {
            return false;
        }
    };

    // action which asserts and throws a user defined exception
    template < typename Exception >
    struct fail_action_ex
    {
        template < typename CreatorPointer >
        static bool invoke ( CreatorPointer )
        {
            BOOST_ASSERT ( !"Operation failed" );
            ::boost::throw_exception ( Exception (  ) );
        }
    };

    // action which asserts and throws a singleton_exception
    typedef fail_action_ex < singleton_exception > fail_action;

    // action which creates the singleton instance if it does not yet
    // exist, and blocks the operation if creation fails
    struct create_action
    {
        template < typename CreatorPointer >
        static bool invoke ( CreatorPointer creator )
        {
            creator->create (  );
            return creator->exists (  );
        }
    };

    // action which destroys the singleton instance if it exists,
    // never fails
    struct destroy_action
    {
        template < typename CreatorPointer >
        static bool invoke ( CreatorPointer creator )
        {
            creator->destroy (  );
            return true;
        }
    };
} }

#endif//BOOST_SINGLETON_PTR_ACTIONS_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
