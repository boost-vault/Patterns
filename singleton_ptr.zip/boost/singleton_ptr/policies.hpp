
//////////////////////////////////////////////////////////////////////////////
// policies.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 10.04.2005
// Purpose: Provide default policies and policy setter metafunctions.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_POLICIES_INCLUDED_
#define BOOST_SINGLETON_PTR_POLICIES_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/singleton_ptr/config.hpp>
#include <boost/singleton_ptr/actions.hpp>
#include <boost/singleton_ptr/static_storage.hpp>
#include <boost/singleton_ptr/in_place_factory.hpp>
#include <boost/singleton_ptr/factory_creator.hpp>
#include <boost/singleton_ptr/static_lifetime.hpp>
#include <boost/singleton_ptr/single_threaded.hpp>
#include <boost/singleton_ptr/singleton_map.hpp>

namespace boost
{
    namespace singleton
    {
        struct unnamed {  };

        struct policy_setter
        {
            // default name
            typedef ::boost::singleton::unnamed instance_name;

            // default major policies
            typedef ::boost::singleton::static_storage   storage_policy;
            typedef ::boost::singleton::factory_creator
                < ::boost::singleton::in_place_factory > creator_policy;
            typedef ::boost::singleton::static_lifetime  lifetime_policy;
            typedef ::boost::singleton::single_threaded  threading_policy;

            // used by multiton
            typedef ::boost::singleton::map multiton_container_policy;

            // default minor policies (action specifiers)
            typedef ::boost::singleton::create_action
                pointer_creation_action;

            typedef ::boost::singleton::create_action
                pointer_dereferencing_action;
        };

        // the following are used to specify the named
        // template arguments to singleton_type

        struct default_policy : public virtual policy_setter
        {
        };

        template < typename Type >
        struct name : public virtual policy_setter
        {
            typedef Type instance_name;
        };

        template < typename Type >
        struct storage : public virtual policy_setter
        {
            typedef Type storage_policy;
        };

        template < typename Type >
        struct creator : public virtual policy_setter
        {
            typedef Type creator_policy;
        };

        template < typename Type >
        struct factory : public virtual policy_setter
        {
            typedef ::boost::singleton::factory_creator
                < Type > creator_policy;
        };

        template < typename Type >
        struct lifetime : public virtual policy_setter
        {
            typedef Type lifetime_policy;
        };

        template < typename Type >
        struct threading : public virtual policy_setter
        {
            typedef Type threading_policy;
        };

        template < typename Type >
        struct multiton_container : public virtual policy_setter
        {
            typedef Type multiton_container_policy;
        };

        template < typename Type >
        struct on_creation : public virtual policy_setter
        {
            typedef Type pointer_creation_action;
        };

        template < typename Type >
        struct on_dereference : public virtual policy_setter
        {
            typedef Type pointer_dereferencing_action;
        };

        // create the instance upon creation of a pointer to it
        struct greedy_creation : public virtual policy_setter
        {
            typedef ::boost::singleton::create_action
                pointer_creation_action;
            typedef ::boost::singleton::create_action
                pointer_dereferencing_action;
        };

        // create the instance when a pointer to it is dereferenced
        struct lazy_creation : public virtual policy_setter
        {
            typedef ::boost::singleton::ignore_action
                pointer_creation_action;
            typedef ::boost::singleton::create_action
                pointer_dereferencing_action;
        };

        // do not automatically create the instance
        struct manual_creation : public virtual policy_setter
        {
            typedef ::boost::singleton::ignore_action
                pointer_creation_action;
            typedef ::boost::singleton::ignore_action
                pointer_dereferencing_action;
        };
    }
}

#endif//BOOST_SINGLETON_PTR_POLICIES_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revised: <never>
//
//////////////////////////////////////////////////////////////////////////////
