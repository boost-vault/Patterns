
//////////////////////////////////////////////////////////////////////////////
// dependency_lifetime.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.14.2005
// Purpose: Pointers and references share a reference count, when this drops
//          to zero the instance is destroyed. const_pointer does not
//          participate in reference counting or automatic destrction.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_DEPENDENCY_LIFETIME_INCLUDED_
#define BOOST_SINGLETON_PTR_DEPENDENCY_LIFETIME_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/detail/no_exceptions_support.hpp>
#include <boost/assert.hpp>

namespace boost { namespace singleton
{
    struct dependency_lifetime
    {
        template
        <
            typename Name,
            typename Type,
            typename Threading
        >
        class lifetime
        {
        public:
            typedef lifetime < Name, Type, Threading > lifetime_type;

            // internal policy types
            typedef Threading threading_type;
            typedef typename threading_type::creator_type creator_type;

            // action function signature used for callbacks during
            // pointer creation and pointer dereferencing
            typedef bool ( *action_type )( creator_type * );

            // inner pointer types
            typedef typename
                threading_type::reference     inner_reference;
            typedef typename
                threading_type::pointer       inner_pointer;
            typedef typename
                threading_type::const_pointer inner_const_pointer;

            // syncronization types
            typedef typename
                threading_type::mutex_type mutex_type;
            typedef typename
                threading_type::read_lock_type read_lock_type;
            typedef typename
                threading_type::write_lock_type write_lock_type;

        private:
            // member vars
            threading_type threading_inst;
            unsigned int refcount;

        public:
            struct reference
            {
            private:
                // member vars
                lifetime_type * lifetime_ptr;
                inner_reference inner;

            public:
                reference ( lifetime_type * lifetime_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : lifetime_ptr ( lifetime_ptr )
                    , inner ( lifetime_ptr->get_threading (  ),
                                on_creation, on_dereference )
                {
                    ++lifetime_ptr->refcount;
                }

                ~ reference (  )
                {
                    // we are actually still holding the lock here
                    // decrement refcount, destroy instance
                    // once it reaches zero
                    if ( !--lifetime_ptr->refcount )
                    {
                        lifetime_ptr->get_threading (  )->
                            get_creator (  )->destroy (  );
                    }
                }

                operator Type & (  )
                {
                    return inner;
                }

                operator const Type & (  ) const
                {
                    return inner;
                }
            };

            struct const_pointer;

            struct pointer
            {
            private:
                lifetime_type * lifetime_ptr;
                inner_pointer inner;

            public:
                pointer ( lifetime_type * lifetime_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : lifetime_ptr ( lifetime_ptr )
                    , inner ( lifetime_ptr->get_threading (  ),
                                on_creation, on_dereference )
                {
                    ++lifetime_ptr->refcount;
                }

                ~ pointer (  )
                {
                    BOOST_TRY
                    {
                        // acquire a lock
                        write_lock_type guard ( lifetime_ptr->
                            get_threading (  )->get_mutex (  ) );
                        ( void ) guard; // disable unused variable warnings

                        // decrement refcount, destroy instance
                        // once it reaches zero
                        if ( !--lifetime_ptr->refcount )
                        {
                            lifetime_ptr->get_threading (  )->
                                get_creator (  )->destroy (  );
                        }
                    }
                    BOOST_CATCH ( ... )
                    {
                        // if we could not acquire a lock then
                        // don't attempt to destroy the instance

                        // this is potentially really bad because the
                        // reference count cannot be set correctly,
                        // so destruction of the lifetime policy
                        // also attempts destruction of the instance
                        // just in case

                        // but even that can be problematic, because
                        // order of destruction of singleton instances
                        // is no longer assured, and depending on the
                        // storage policy phoenix creation may or may
                        // not be safe

                        BOOST_ASSERT ( ! \
                            "Strange things might happen if you continue." );
                    }
                    BOOST_CATCH_END
                }

                const inner_pointer & operator -> (  ) const
                {
                    return inner;
                }

                // allow access to threading_ptr for implicit conversion
                friend struct const_pointer;
            };

            struct const_pointer
            {
            private:
                inner_const_pointer inner;

            public:
                const_pointer ( lifetime_type * const lifetime_ptr )
                    : inner ( lifetime_ptr->get_threading (  ) )
                {
                }

                const_pointer ( const pointer & ptr )
                    : inner ( ptr.lifetime_ptr->get_threading (  ) )
                {
                }

                const inner_const_pointer & operator -> (  ) const
                {
                    return inner;
                }
            };

            // initialize refcount
            lifetime (  )
                : refcount ( 0 )
            {
            }

            ~ lifetime (  )
            {
                // this operation does not need to be locked,
                // because we are guarenteed that when the policy
                // is being destroyed this is the only thread or
                // process with access to this singleton
                threading_inst.get_creator (  )->destroy (  );
            }

            // give smart pointer types access to refcount
            friend struct reference;
            friend struct pointer;
            friend struct const_pointer;

            // get pointer to threading policy
            threading_type * get_threading (  )
            {
                return &threading_inst;
            }

            // get const pointer to threading policy
            threading_type * const get_threading (  ) const
            {
                return &threading_inst;
            }
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_DEPENDENCY_LIFETIME_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
