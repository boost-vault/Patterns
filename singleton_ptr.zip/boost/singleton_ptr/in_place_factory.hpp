
//////////////////////////////////////////////////////////////////////////////
// in_place_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which uses
//          aligned_storage to construct and destroy an instance in place.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_IN_PLACE_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_IN_PLACE_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <cstddef>
#include <boost/aligned_storage.hpp>

#include <boost/assert.hpp>

// the following are required for generation of create functions
#include <boost/preprocessor/punctuation/comma.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/dynamic_type_tag.hpp>

namespace boost { namespace singleton
{
    template < typename StorageSize >
    struct in_place_factory_ex
    {
        template
        <
            typename Name,
            typename Type
        >
        struct factory
        {
        public:
            // provide access to size
            enum values
            {
                storage_size = StorageSize::get_size
                    < Type >::value
            };

        private:
            // type of storage buffer
            typedef typename ::boost::aligned_storage
                < storage_size >::type storage_type;

            // used to validate that created type can fit inside buffer
            template < bool BigEnough >
            struct in_place_buffer_too_small {  };

            // only true case has a nested type
            template <  >
            struct in_place_buffer_too_small < true >
            {
                typedef in_place_buffer_too_small < true > type;
            };

            // member vars
            storage_type storage;

        public:
            // required typedefs
            typedef Type & reference;
            typedef Type * pointer;
            typedef Type * const const_pointer;

            // create instance in buffer
            // overwrites if instance already exists
            pointer create (  )
            {
                // NOTICE!
                // If a compiler error took you around here, the type of the
                // singleton you are trying to create is too big to fit in the
                // buffer.  You need to use in_place_factory_ex, and provide a
                // metafunction which returns a bigger value for the size
                // of storage to use.
                typedef typename in_place_buffer_too_small
                    < sizeof ( Type ) <= storage_size >::type unused_type;

                Type * ptr = reinterpret_cast < Type * > ( &storage );
                new ( ptr ) Type (  );
                return ptr;
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                typedef typename in_place_buffer_too_small                  \
                    < sizeof ( Type ) <= storage_size >::type unused_type;  \
                Type * ptr = reinterpret_cast < Type * > ( &storage );      \
                new ( ptr ) Type ( BOOST_PP_ENUM_PARAMS(n, p) );            \
                return ptr;                                                 \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // overload taking a dynamic_type_tag as a first parameter
            template < typename Tag >
            pointer create ( const ::boost::singleton::dynamic_type_tag
                < Tag > & )
            {
                // NOTICE!
                // If a compiler error took you around here, the type of the
                // singleton you are trying to create is too big to fit in the
                // buffer.  You need to use in_place_factory_ex, and provide a
                // metafunction which returns a bigger value for the size
                // of storage to use.
                typedef typename in_place_buffer_too_small
                    < sizeof ( Tag ) <= storage_size >::type unused_type;

                Tag * ptr = reinterpret_cast < Tag * > ( &storage );
                new ( ptr ) Tag (  );
                return ptr;
            }

            // generate create function overloads taking
            // a dynamic_type_tag as a first parameter
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < typename Tag, BOOST_PP_ENUM_PARAMS(n, typename P) >  \
            pointer create ( const ::boost::singleton::dynamic_type_tag     \
                < Tag > & BOOST_PP_COMMA()                                  \
                BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )              \
            {                                                               \
                typedef typename in_place_buffer_too_small                  \
                    < sizeof ( Tag ) <= storage_size >::type unused_type;   \
                Tag * ptr = reinterpret_cast < Tag * > ( &storage );        \
                new ( ptr ) Tag ( BOOST_PP_ENUM_PARAMS(n, p) );             \
                return ptr;                                                 \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // destroy instance
            void destroy ( pointer ptr )
            {
                BOOST_ASSERT ( \
                    reinterpret_cast < pointer > ( &storage ) == ptr );
                ptr->~Type (  );
            }
        };
    };

    // default storage size 'policy', returns sizeof ( Type )
    struct simple_in_place_size
    {
        template < typename Type >
        struct get_size
        {
            enum values
            {
                value = sizeof ( Type )
            };
        };
    };

    // explicit size specifier, the 'hit it til it works' method :-P
    template < ::std::size_t Size >
    struct explicit_in_place_size
    {
        template < typename Type >
        struct get_size
        {
            enum values
            {
                value = Size
            };
        };
    };

    typedef in_place_factory_ex < simple_in_place_size > in_place_factory;
} }

#endif//BOOST_SINGLETON_PTR_IN_PLACE_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
