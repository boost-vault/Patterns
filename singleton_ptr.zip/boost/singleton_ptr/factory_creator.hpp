
//////////////////////////////////////////////////////////////////////////////
// factory_creator.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.16.2005
// Purpose: Provide creator policy for singleton_ptr library which can
//          be customized to use an arbitrary factory to create the instance.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_FACTORY_CREATOR_INCLUDED_
#define BOOST_SINGLETON_PTR_FACTORY_CREATOR_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

// the following are required for generation of create functions
#include <boost/preprocessor/punctuation/comma.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

// defines exceptions which can be thrown if creation or dereferencing fails
#include <boost/singleton_ptr/exceptions.hpp>

namespace boost { namespace singleton
{
    template < typename Factory >
    struct factory_creator
    {
        template
        <
            typename Name,
            typename Type
        >
        class creator
        {
        public:
            // factory policy type
            typedef typename Factory::
                template factory < Name, Type > factory_type;

            // creator policy type (current template instantiation)
            typedef creator < Name, Type > creator_type;

            // internal pointer types inherited from factory policy
            typedef typename factory_type::reference inner_reference;
            typedef typename factory_type::pointer inner_pointer;
            typedef typename factory_type::const_pointer inner_const_pointer;

        private:
            // member vars
            inner_pointer ptr;
            factory_type factory;

        public:
            // action function signature used for callbacks during
            // pointer creation and pointer dereferencing
            typedef bool ( *action_type )( creator_type * );

            // smart reference to singleton instance
            // non-const instances can be used to modify singleton state
            struct reference
            {
            private:
                // member vars
                creator_type * creator_ptr;
                action_type on_dereference;

            public:
                // must be provided with a pointer to the creator
                // and the actions to invoke upon creation and
                // dereferencing of the pointer
                reference ( creator_type * creator_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : creator_ptr ( creator_ptr )
                    , on_dereference ( on_dereference )
                {
                    // if the action to take upon pointer creation fails by
                    // returning false, an exception is thrown
                    if ( !on_creation ( creator_ptr ) )
                    {
                        ::boost::throw_exception (
                            invalid_pointer_creation (  ) );
                    }
                }

                // dereference of a non-const reference calls the
                // dereferencing action before returning the inner pointer; if
                // the dereferencing action fails or the instance does not
                // exist after the action is invoked, an exception will be
                // thrown
                operator Type & (  )
                {
                    if ( !on_dereference ( creator_ptr ) ||
                         !creator_ptr->exists (  ) )
                    {
                        ::boost::throw_exception ( invalid_dereference (  ) );
                    }
                    return *( creator_ptr->get_pointer (  ) );
                }

                // dereference of a const reference throws an exception if the
                // instance does not already exist
                operator const Type & (  ) const
                {
                    if ( !creator_ptr->exists (  ) )
                    {
                        ::boost::throw_exception ( invalid_dereference (  ) );
                    }
                    // make sure we have a pointer to const
                    creator_type * const const_creator_ptr = creator_ptr;
                    // then call the const version of get_pointer
                    return *( const_creator_ptr->get_pointer (  ) );
                }
            };

            // forward declaration
            struct const_pointer;

            // smart pointer to instance
            // can be used to modify singleton state
            struct pointer
            {
            private:
                // member vars
                creator_type * creator_ptr;
                action_type on_dereference;

            public:
                // must be provided with a pointer to the creator
                // and the actions to invoke upon creation and
                // dereferencing of the pointer
                pointer ( creator_type * creator_ptr,
                          action_type on_creation,
                          action_type on_dereference )

                    : creator_ptr ( creator_ptr )
                    , on_dereference ( on_dereference )
                {
                    // if the action to take upon pointer creation fails
                    // by returning false, an exception is thrown
                    if ( !on_creation ( creator_ptr ) )
                    {
                        ::boost::throw_exception (
                            invalid_pointer_creation (  ) );
                    }
                }

                // dereference always calls the dereferencing action before
                // returning the inner pointer; if the dereferencing action
                // fails or the instance does not exist after the action is
                // invoked an exception is thrown
                const inner_pointer & operator -> (  ) const
                {
                    if ( !on_dereference ( creator_ptr ) ||
                         !creator_ptr->exists (  ) )
                    {
                        ::boost::throw_exception ( invalid_dereference (  ) );
                    }
                    return creator_ptr->ptr;
                }

                // allow access to creator_ptr for implicit conversion
                friend struct const_pointer;
            };

            // smart pointer to instance
            // is forbidden from modifying singleton state
            struct const_pointer
            {
            private:
                // member vars
                creator_type * const creator_ptr;

            public:
                // takes only a pointer to a const creator_type, does not take
                // any actions because actions may modify the singleton state
                const_pointer ( creator_type * const creator_ptr )
                    : creator_ptr ( creator_ptr )

                {
                }

                // implicitly constructable from pointer
                const_pointer ( const pointer & ptr )
                    // const_pointer is a friend of pointer, and thus has
                    // access to creator_ptr
                    : creator_ptr ( ptr.creator_ptr )
                {
                }

                // throws if instance does not exist
                const inner_const_pointer & operator -> (  ) const
                {
                    if ( !creator_ptr->exists (  ) )
                    {
                        ::boost::throw_exception ( invalid_dereference (  ) );
                    }
                    return creator_ptr->get_pointer (  );
                }
            };

            // create the instance if it does not already exist
            void create (  )
            {
                if ( ptr ) return;
                ptr = factory.create (  );
            }

            // generate create functions taking any number of params that are
            // forwarded to factory create function
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            void create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )    \
            {                                                               \
                if ( ptr ) return;                                          \
                ptr = factory.create ( BOOST_PP_ENUM_PARAMS(n, p) );        \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // destroy the instance if it exists
            void destroy (  )
            {
                if ( ptr )
                {
                    factory.destroy ( ptr );
                    ptr = 0;
                }
            }

            // get a pointer to the current instance
            inner_pointer get_pointer (  )
            {
                return ptr;
            }

            // get a const_pointer to the current instance
            inner_const_pointer get_pointer (  ) const
            {
                return ptr;
            }

            // check if the instance currently exists
            bool exists (  ) const
            {
                return ptr != 0;
            }

            // initialize pointer to null
            creator (  )
                : ptr ( 0 )
                , factory (  )
            {
            }
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_FACTORY_CREATOR_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
