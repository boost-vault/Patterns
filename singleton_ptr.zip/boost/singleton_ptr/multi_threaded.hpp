
////////////////////////////////////////////////////////////////////////////////
// multi_threaded.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.13.2005
// Purpose: Specialization of multi_threaded_ex designed to work with
//          the Boost Threads library.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_MULTI_THREADED_INCLUDED_
#define BOOST_SINGLETON_PTR_MULTI_THREADED_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/thread/mutex.hpp>
#include <boost/singleton_ptr/multi_threaded_ex.hpp>

namespace boost { namespace singleton
{
    typedef ::boost::singleton::multi_threaded_ex
    <
        ::boost::singleton::mutex_wrapper < ::boost::mutex >

    > multi_threaded;
} }

#endif//BOOST_SINGLETON_PTR_MULTI_THREADED_INCLUDED_

////////////////////////////////////////////////////////////////////////////////
// Revision history:
//
////////////////////////////////////////////////////////////////////////////////
