
//////////////////////////////////////////////////////////////////////////////
// exceptions.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.03.2005
// Purpose: Define all exceptions used with the singleton_ptr library.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_EXCEPTIONS_INCLUDED_
#define BOOST_SINGLETON_PTR_EXCEPTIONS_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <stdexcept>
#include <boost/throw_exception.hpp>

namespace boost { namespace singleton
{
    // base class for all singleton exceptions
    // derives from std::runtime_error
    class singleton_exception : public std::runtime_error
    {
    public:
        singleton_exception ( const char * msg =
            "Attempted operation on singleton failed." )

            : std::runtime_error ( msg )
        {
        }
    };

    // exception thrown when singleton instance creation fails
    class invalid_creation : public singleton_exception
    {
    public:
        invalid_creation (  )
            : singleton_exception (
                "Creation of the singleton instance has been forbidden." )
        {
        }
    };

    // exception thrown when pointer creation fails
    class invalid_pointer_creation : public singleton_exception
    {
    public:
        invalid_pointer_creation (  )
            : singleton_exception (
                "Creation of singleton smart pointer failed." )
        {
        }
    };

    // exception thrown when a singleton cannot be dereferenced,
    // most likely because the instance does not exist and any automated
    // creation functionality has failed
    class invalid_dereference : public singleton_exception
    {
    public:
        invalid_dereference (  )
            : singleton_exception (
                "The singleton instance cannot be dereferenced." )
        {
        }
    };
} }

#endif//BOOST_SINGLETON_PTR_EXCEPTIONS_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
