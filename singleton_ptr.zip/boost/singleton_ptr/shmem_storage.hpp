
//////////////////////////////////////////////////////////////////////////////
// shmem_storage.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 08.01.2005
// Purpose: Storage policy which ensures that policy instances are unique
//          across process boundaries, and are only released when all
//          processes using them have exited.  Requires that the shmem library
//          be available, which is not yet an official boost library.  You can
//          download shmem from http://tinyurl.com/9t5qy.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_SHMEM_STORAGE_INCLUDED_
#define BOOST_SINGLETON_PTR_SHMEM_STORAGE_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <cstddef>
#include <boost/assert.hpp>

#include <boost/shmem/shared_memory.hpp>
#include <boost/shmem/shmem_named_shared_object.hpp>
#include <boost/shmem/sync/named_semaphore.hpp>

#include <boost/singleton_ptr/config.hpp>
#include <boost/singleton_ptr/collective_storage.hpp>

namespace boost
{
    namespace singleton
    {
        // Requires Name to define the static member function
        // type_name, which take no arguments and returns a unique
        // identifier.  This identifier should remain consistent
        // between program runs, and be prefixed by a forward slash.
        template < ::std::size_t ExtraSpace >
        struct shmem_accessor
        {
            template
            <
                typename Name,
                typename Type
            >
            struct accessor
            {
            private:
                // store a refcount with the instance
                struct holder
                {
                    int refcount;
                    Type inst;

                    holder (  )
                        : refcount ( 0 )
                    {
                    }
                };

                // our interface to the shared memory segment
                ::boost::shmem::named_shared_object shobj;
                // pointer to the instance
                holder * pholder;

            public:
                enum values
                {
                    extra_space = ExtraSpace
                };

                typedef Type * pointer;

                // set up shared memory access and perform memory mapping
                accessor (  )
                    : pholder ( 0 )
                {
                    // if we can not open an existing segment...
                    if ( !shobj.open ( Name::type_name (  ), 0 ) )
                    {
                        // then we must create it
                        BOOST_ASSERT ( shobj.create ( Name::type_name (  ), \
                            sizeof ( Type ) + extra_space ) );

                        // We add extra_space to make sure that there is
                        // enough room for whatever behind the scenes
                        // management shmem requires.  If this fails, the
                        // number may need to be increased.
                    }

                    pholder = shobj.find < holder > (
                        ::boost::shmem::unique_instance ).first;

                    // construct policy instance in storage
                    // if it does not yet exist
                    if ( !pholder )
                    {
                        pholder = shobj.construct < holder > (
                            ::boost::shmem::unique_instance )(  );
                    }
                    // increment reference count
                    ++pholder->refcount;
                }

                // get instance of the policy
                pointer instance (  )
                {
                    return &pholder->inst;
                }

                // decrement refcount, destroy policy when it drops to zero
                ~ accessor (  )
                {
                    --pholder->refcount;

                    if ( !pholder->refcount )
                    {
                        shobj.destroy < holder > (
                            ::boost::shmem::unique_instance );
                    }
                }
            };
        };

        // Requires Name to define the static member function
        // lock_name, which take no arguments and returns a unique
        // identifier.  This identifier should remain consistent
        // between program runs, be prefixed by a forward slash,
        // and be different from the string returned by type_name().
        struct shmem_mutex
        {
            template
            <
                typename Name,
                typename Type
            >
            struct mutex
            {
                struct mutex_type
                {
                    // use named semaphore to serialize access
                    struct shared_lock
                    {
                    private:
                        ::boost::shmem::named_semaphore guard;

                    public:
                        // provide a default ctor because the mutex
                        // doesn't actually matter
                        shared_lock (  )
                        {
                            guard.open_or_create ( Name::lock_name (  ),
                                BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS );
                            guard.wait (  );
                        }

                        // provide a ctor taking a mutex, because the
                        // multi_threading policy expects that
                        shared_lock ( const mutex_type & mux )
                        {
                            guard.open_or_create ( Name::lock_name (  ),
                                BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS );
                            guard.wait (  );
                        }

                        // release the lock
                        ~ shared_lock (  )
                        {
                            guard.post (  );
                        }
                    };

                    // use named semaphore to serialize access
                    struct scoped_lock
                    {
                    private:
                        ::boost::shmem::named_semaphore guard;

                    public:
                        // provide a default ctor because the mutex
                        // doesn't actually matter
                        scoped_lock (  )
                        {
                            guard.open_or_create ( Name::lock_name (  ),
                                BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS );

                            // acquire all available locks,
                            // giving us exclusive access
                            for ( int i = 0;
                                i < BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS;
                                ++i ) guard.wait (  );
                        }

                        // provide a ctor taking a mutex, because the
                        // multi_threading policy expects that
                        scoped_lock ( const mutex_type & mux )
                        {
                            guard.open_or_create ( Name::lock_name (  ),
                                BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS );

                            // acquire all available locks,
                            // giving us exclusive access
                            for ( int i = 0;
                                i < BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS;
                                ++i ) guard.wait (  );
                        }

                        // release the lock
                        ~ scoped_lock (  )
                        {
                            // release all of them,
                            // since we acquired all of them
                            for ( int i = 0;
                                i < BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS;
                                ++i ) guard.post (  );
                        }
                    };
                };

                // lock types
                typedef typename mutex_type::shared_lock read_lock_type;
                typedef typename mutex_type::scoped_lock write_lock_type;
            };
        };

        // use a special shmem mutex to serialize access
        struct shmem_atomic_call
        {
            static const char * lock_name (  )
            {
                return "/boost_singleton_shmem_atomic_call_lock";
            }

            template
            <
                typename Name,
                typename Type
            >
            struct atomic_call
            {
            public:
                static void invoke ( void ( *func )(  ) )
                {
                    typename shmem_mutex::mutex
                    <
                        ::boost::singleton::shmem_atomic_call,
                        ::boost::singleton::shmem_atomic_call

                    > ::write_lock_type guard; // serialize access
                    ( void ) guard; // disable unused variable warnings

                    // invoke the callback function
                    func (  );
                }
            };
        };

        // shmem_storage uses a unique instance residing in shared
        // memory, but does not serialize access to it.  Use this if
        // you have a complex linking situation where a dll containing
        // the singleton can be loaded multiple times, but the singleton
        // will only ever be accessed by a single thread from a single
        // process.
        typedef ::boost::singleton::collective_storage_ex
        <
            shmem_accessor < BOOST_SINGLETON_PTR_SHMEM_EXTRA_SPACE >,
            simple_atomic_call

        > shmem_storage;

        // shmem_locked_storage uses a unique instance residing in
        // shared memory, and serializes all access to it.  Use this if
        // you want a single instance shared among multiple threads
        // and/or processes.
        typedef ::boost::singleton::collective_storage_ex
        <
            shmem_accessor < BOOST_SINGLETON_PTR_SHMEM_EXTRA_SPACE >,
            shmem_atomic_call

        > shmem_locked_storage;
    }
}

#endif//BOOST_SINGLETON_PTR_SHMEM_STORAGE_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
