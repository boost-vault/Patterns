
//////////////////////////////////////////////////////////////////////////////
// config.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.08.2005
// Purpose: Default definitions pertaining to singleton_ptr library.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_CONFIG_INCLUDED_
#define BOOST_SINGLETON_PTR_CONFIG_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

// number of arguments which can be passed to constructor via a create call
#ifndef BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS
#define BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS 8
#endif

// extra space for instance in shared memory, increase if shmem has issues
#ifndef BOOST_SINGLETON_PTR_SHMEM_EXTRA_SPACE
#define BOOST_SINGLETON_PTR_SHMEM_EXTRA_SPACE 1024
#endif

// number of shared locks allowed to be acquired for shmem_threading
#ifndef BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS
#define BOOST_SINGLETON_PTR_SHMEM_SHARED_LOCKS 8
#endif

#endif//BOOST_SINGLETON_PTR_CONFIG_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
