
//////////////////////////////////////////////////////////////////////////////
// throw_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which always
//          fails by throwing an exception.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_THROW_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_THROW_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

// the following are required for generation of create functions
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/exceptions.hpp>

namespace boost { namespace singleton
{
    template < typename Exception >
    struct throw_factory_ex
    {
        template
        <
            typename Name,
            typename Type
        >
        struct factory
        {
        public:
            // required typedefs
            typedef Type & reference;
            typedef Type * pointer;
            typedef Type * const const_pointer;

            // always throws
            pointer create (  )
            {
                ::boost::throw_exception ( Exception (  ) );
                return 0; // never reached
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                ::boost::throw_exception ( Exception (  ) );                \
                return 0;                                                   \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // no-op
            void destroy ( pointer ptr )
            {
            }
        };
    };

    typedef throw_factory_ex
    <
        ::boost::singleton::invalid_creation

    > throw_factory;
} }

#endif//BOOST_SINGLETON_PTR_THROW_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
