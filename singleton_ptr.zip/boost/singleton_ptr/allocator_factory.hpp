
//////////////////////////////////////////////////////////////////////////////
// allocator_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which uses
//          a standard allocator to manage memory for the singleton instance.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_ALLOCATOR_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_ALLOCATOR_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <memory>

#include <boost/config.hpp>
#include <boost/assert.hpp>
#include <boost/static_assert.hpp>

// the following are required for generation of create functions
#include <boost/preprocessor/punctuation/comma.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/dynamic_type_tag.hpp>

namespace boost { namespace singleton
{
    // most allocators define const_pointer to mean const Type *
    // but we need it to mean Type * const, so we use the following
    // metafunction to get the semantically correct const_pointer.

    // this should be specialized for allocators that provide a
    // semantically correct const_pointer type (specifically shmem).
    template < typename Allocator >
    struct allocator_const_pointer
    {
        typedef Allocator * const type;
    };

    // general case, can throw
    template
    <
        typename Allocator,
        bool NoThrow =
        // set default based on detected compiler capabilities
        #ifdef BOOST_NO_EXCEPTIONS
            true
        #else
            false
        #endif
    >
    struct allocator_factory_ex
    {
        // require use of NoThrow variant if exceptions are not supported
        #ifdef BOOST_NO_EXCEPTIONS
            BOOST_STATIC_ASSERT ( NoThrow || !"Exceptions are not enabled." );
        #endif

        template
        <
            typename Name,
            typename Type
        >
        struct factory
        {
        private:
            // we must use a char allocator so that we can specify
            // the amount of memory to allocate directly
            typedef typename Allocator::
                template rebind < char >::other allocator_type;

            // but we must typedef the pointer types from the correct one
            typedef typename Allocator::
                template rebind < Type >::other internal_allocator_type;

            // member vars
            allocator_type allocator;

            // memory releaser in case construction throws
            struct free_on_error
            {
            private:
                bool release;
                allocator_type & allocator;
                typename allocator_type::pointer memory;
                typename allocator_type::size_type size;

            public:
                free_on_error ( allocator_type & allocator,
                            typename allocator_type::pointer memory,
                            typename allocator_type::size_type size )

                    : release ( true )
                    , allocator ( allocator )
                    , memory ( memory )
                    , size ( size )
                {
                }

                void discard (  )
                {
                    release = false;
                }

                ~ free_on_error (  )
                {
                    if ( release ) allocator.deallocate ( memory, size );
                }
            };

        public:
            // required typedefs
            typedef typename internal_allocator_type::reference reference;
            typedef typename internal_allocator_type::pointer pointer;
            typedef typename ::boost::singleton::allocator_const_pointer
                < internal_allocator_type >::type const_pointer;

            // allocate memory and create instance
            pointer create (  )
            {
                Type * ptr = reinterpret_cast < Type * > (
                    allocator.allocate ( sizeof ( Type ) ) );

                if ( !ptr )
                {
                    if ( NoThrow ) return 0;
                    else ::boost::throw_exception ( ::std::bad_alloc (  ) );
                }
                free_on_error guard ( allocator, reinterpret_cast < char * >
                    ( ptr ), sizeof ( Type ) );
                new ( ptr ) Type (  );
                guard.discard (  );
                return ptr;
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                Type * ptr = reinterpret_cast < Type * > (                  \
                    allocator.allocate ( sizeof ( Type ) ) );               \
                if ( !ptr )                                                 \
                {                                                           \
                    if ( NoThrow ) return 0;                                \
                    else ::boost::throw_exception ( ::std::bad_alloc (  ) );\
                }                                                           \
                free_on_error guard ( allocator, reinterpret_cast < char * >\
                    ( ptr ), sizeof ( Type ) );                             \
                new ( ptr ) Type ( BOOST_PP_ENUM_PARAMS(n, p) );            \
                guard.discard (  );                                         \
                return ptr;                                                 \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // overload taking a dynamic_type_tag as a first parameter
            template < typename Tag >
            pointer create ( const ::boost::singleton::dynamic_type_tag
                < Tag > & )
            {
                Tag * ptr = reinterpret_cast < Tag * > (
                    allocator.allocate ( sizeof ( Tag ) ) );
                if ( !ptr )
                {
                    if ( NoThrow ) return 0;
                    else ::boost::throw_exception ( ::std::bad_alloc (  ) );
                }
                free_on_error guard ( allocator, reinterpret_cast < char * >
                    ( ptr ), sizeof ( Tag ) );
                new ( ptr ) Tag (  );
                guard.discard (  );
                return ptr;
            }

            // generate create function overloads taking
            // a dynamic_type_tag as a first parameter
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < typename Tag, BOOST_PP_ENUM_PARAMS(n, typename P) >  \
            pointer create ( const ::boost::singleton::dynamic_type_tag     \
                < Tag > & BOOST_PP_COMMA()                                  \
                BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )              \
            {                                                               \
                Tag * ptr = reinterpret_cast < Tag * > (                    \
                    allocator.allocate ( sizeof ( Tag ) ) );                \
                if ( !ptr )                                                 \
                {                                                           \
                    if ( NoThrow ) return 0;                                \
                    else ::boost::throw_exception ( ::std::bad_alloc (  ) );\
                }                                                           \
                free_on_error guard ( allocator, reinterpret_cast < char * >\
                    ( ptr ), sizeof ( Tag ) );                              \
                new ( ptr ) Tag ( BOOST_PP_ENUM_PARAMS(n, p) );             \
                guard.discard (  );                                         \
                return ptr;                                                 \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // destroy instance
            void destroy ( pointer ptr )
            {
                BOOST_ASSERT ( ptr );
                delete ptr;
            }
        };
    };

    typedef allocator_factory_ex
    <
        ::std::allocator < char >

    > allocator_factory;
} }

#endif//BOOST_SINGLETON_PTR_ALLOCATOR_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
