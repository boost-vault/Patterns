
//////////////////////////////////////////////////////////////////////////////
// unmanaged_lifetime.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Does not perform automatic destruction of the singleton instance.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_UNMANAGED_LIFETIME_INCLUDED_
#define BOOST_SINGLETON_PTR_UNMANAGED_LIFETIME_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

namespace boost { namespace singleton
{
    struct unmanaged_lifetime
    {
        template
        <
            typename Name,
            typename Type,
            typename Threading
        >
        class lifetime
        {
        public:
            typedef lifetime < Name, Type, Threading > lifetime_type;

            // internal policy types
            typedef Threading threading_type;
            typedef typename threading_type::creator_type creator_type;

            // action function signature used for callbacks during
            // pointer creation and pointer dereferencing
            typedef bool ( *action_type )( creator_type * );

            // inner pointer types
            typedef typename
                threading_type::reference     inner_reference;
            typedef typename
                threading_type::pointer       inner_pointer;
            typedef typename
                threading_type::const_pointer inner_const_pointer;

            // syncronization types
            typedef typename
                threading_type::mutex_type mutex_type;
            typedef typename
                threading_type::read_lock_type read_lock_type;
            typedef typename
                threading_type::write_lock_type write_lock_type;

        private:
            // member vars
            threading_type threading_inst;

        public:
            struct reference
            {
            private:
                // member vars
                inner_reference inner;

            public:
                reference ( lifetime_type * lifetime_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : inner ( lifetime_ptr->get_threading (  ),
                                on_creation, on_dereference )
                {
                }

                operator Type & (  )
                {
                    return inner;
                }

                operator const Type & (  ) const
                {
                    return inner;
                }
            };

            struct const_pointer;

            struct pointer
            {
            private:
                lifetime_type * lifetime_ptr;
                inner_pointer inner;

            public:
                pointer ( lifetime_type * lifetime_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : lifetime_ptr ( lifetime_ptr )
                    , inner ( lifetime_ptr->get_threading (  ),
                                on_creation, on_dereference )
                {
                }

                const inner_pointer & operator -> (  ) const
                {
                    return inner;
                }

                // allow access to threading_ptr for implicit conversion
                friend struct const_pointer;
            };

            struct const_pointer
            {
            private:
                inner_const_pointer inner;

            public:
                const_pointer ( lifetime_type * const lifetime_ptr )
                    : inner ( lifetime_ptr->get_threading (  ) )
                {
                }

                const_pointer ( const pointer & ptr )
                    : inner ( ptr.lifetime_ptr->get_threading (  ) )
                {
                }

                const inner_const_pointer & operator -> (  ) const
                {
                    return inner;
                }
            };

            // get pointer to threading policy
            threading_type * get_threading (  )
            {
                return &threading_inst;
            }

            // get const pointer to threading policy
            threading_type * const get_threading (  ) const
            {
                return &threading_inst;
            }
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_UNMANAGED_LIFETIME_INCLUDED_

////////////////////////////////////////////////////////////////////////////////
// Revision history:
//
////////////////////////////////////////////////////////////////////////////////
