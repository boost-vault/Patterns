
//////////////////////////////////////////////////////////////////////////////
// counted_factory.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.17.2005
// Purpose: Provide factory policy for singleton_ptr library which uses one
//          factory until that factory succeeds a specific number of times,
//          and then switches to another factory for subsequent creations.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_COUNTED_FACTORY_INCLUDED_
#define BOOST_SINGLETON_PTR_COUNTED_FACTORY_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/assert.hpp>

// the following are required for generation of create functions
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/assert_factory.hpp>
#include <boost/singleton_ptr/in_place_factory.hpp>

namespace boost { namespace singleton
{
    template
    <
        typename FirstFactory,
        typename NextFactory = ::boost::singleton::assert_factory,
        unsigned int Count = 1
    >
    struct counted_factory
    {
        template
        <
            typename Name,
            typename Type
        >
        struct factory
        {
        private:
            // typedef factory types
            typedef typename FirstFactory::
                template factory < Name, Type > first_factory;
            typedef typename NextFactory::
                template factory < Name, Type > next_factory;

            // member vars
            unsigned int count;
            unsigned int destroy_count;
            Type * first_ptr[Count];
            bool first_destroyed[Count];
            first_factory first;
            next_factory next;

        public:
            // required typedefs
            typedef Type & reference;
            typedef Type * pointer;
            typedef Type * const const_pointer;

            factory (  )
                : count ( 0 )
                , destroy_count ( 0 )
            {
                // initialize array values
                for ( unsigned int i = 0; i < Count; ++i )
                {
                    first_ptr[i] = 0;
                    first_destroyed[i] = false;
                }
            }

            // asserts in debug mode, passes through
            // to other creator in release mode
            pointer create (  )
            {
                // if we were already successful Count times
                if ( count == Count )
                {
                    // then create using the next factory
                    return next.create (  );
                }
                // otherwise try to create with the first factory
                else if ( first_ptr[count] = first.create (  ) )
                {
                    // if creation was successful increment the count
                    // and return the pointer
                    return first_ptr[count++];
                }
                // creation via first returned null, so we do too
                return 0;
            }

            // generate create functions taking any number of params
            #define BOOST_PP_LOCAL_LIMITS (1,                               \
                BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
            #define BOOST_PP_LOCAL_MACRO(n)                                 \
            template < BOOST_PP_ENUM_PARAMS(n, typename P) >                \
            pointer create ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) ) \
            {                                                               \
                if ( count == Count )                                       \
                {                                                           \
                    return next.create ( BOOST_PP_ENUM_PARAMS(n, p) );      \
                }                                                           \
                else if ( first_ptr[count] =                                \
                    first.create ( BOOST_PP_ENUM_PARAMS(n, p) ) )           \
                {                                                           \
                    return first_ptr[count++];                              \
                }                                                           \
                return 0;                                                   \
            }
            #include BOOST_PP_LOCAL_ITERATE()

            // pass through to originating factory
            void destroy ( pointer ptr )
            {
                BOOST_ASSERT ( ptr );
                // if there are undestroyed pointers from the first factory
                // that have not yet been destroyed
                if ( destroy_count != Count )
                {
                    // then check if this was one of them
                    for ( unsigned int i = 0; i < Count; ++i )
                    {
                        // and if so destroy it, update our state, and return
                        if ( !first_destroyed[i] && ptr == first_ptr[i] )
                        {
                            first.destroy ( ptr );
                            first_destroyed[i] = true;
                            ++destroy_count;
                            return;
                        }
                    }
                }

                // ptr must have come from the next factory,
                // so use that to destroy it
                next.destroy ( ptr );
            }
        };
    };

    typedef counted_factory
    <
        ::boost::singleton::in_place_factory

    > one_time_factory;
} }

#endif//BOOST_SINGLETON_PTR_COUNTED_FACTORY_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
