
//////////////////////////////////////////////////////////////////////////////
// uncreatable.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 09.24.2005
// Purpose: Provide a mechanism to disable creation of a singleton type,
//          while leaving it enabled for the underlying factory.
//
//          To use this:
//
//          * Client code singleton must derive from uncreatable, passing
//            uncreatable the factory to use internally.
//          * Client code must use factory_creator < MySingleton::factory >
//            for its creator policy, which MySingleton aquires by deriving
//            from uncreatable.
//
//          Note that this does not work naturally with the in_place_creator,
//          which assumes the storage size required wrongly.  To work around
//          this, uncreatable_storage_size is provided below, which can be
//          plugged into in_place_factory_ex.
//
//          Example code:
//
//          using namespace boost;
//          using namespace singleton;
//          
//          class MySingleton :
//              public uncreatable
//              <
//                  MySingleton,
//                  in_place_factory_ex < uncreatable_storage_size >
//              >
//          {
//          };
//          
//          typedef singleton_ptr
//          <
//              MySingleton,
//              creator
//              <
//                  factory_creator
//                  <
//                      typename MySingleton::factory
//                  >
//              >
//          > MySingletonPointer;
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_UNCREATABLE_INCLUDED_
#define BOOST_SINGLETON_PTR_UNCREATABLE_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

// the following are required for generation of
// constructors and create functions
#include <boost/preprocessor/punctuation/comma.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/singleton_ptr/config.hpp>

#include <boost/singleton_ptr/dynamic_type_tag.hpp>

namespace boost { namespace singleton
{
    namespace detail
    {
        // factory wrapper that re-enables creation
        template
        <
            typename Base,        // get access to uncreatable
            typename HiddenType,  // get access to hidden_type
            typename Factory,     // factory policy to wrap
            typename MakeConcrete // metafunction used to transform
                                  // uncreatable type to concrete type
        >
        struct uncreatable_factory
        {
            template
            <
                typename Name,
                typename Type
            >
            struct factory : public Factory::factory < Name, Base >
            {
            private:
                // factory we derived from
                typedef typename Factory::factory
                    < Name, Base > base_factory;
                // concrete type derived from base singleton type
                typedef typename MakeConcrete::make_concrete
                    < Type >::type concrete_type;

            public:
                // steal the pointer types from the factory that
                // would actually use the abstract type
                typedef typename Factory::factory
                    < Name, Type >::reference     reference;
                typedef typename Factory::factory
                    < Name, Type >::pointer       pointer;
                typedef typename Factory::factory
                    < Name, Type >::const_pointer const_pointer;

                // create the instance
                pointer create (  )
                {
                    // we must use a dynamic type tag to 'rebind' the created
                    // instance type, after which point we cast it to its true
                    // type and return it, letting it decay to a pointer to
                    // the abstract singleton base that the client code is
                    // aware of
                    return static_cast < pointer > (
                        base_factory::create (
                        ::boost::singleton::dynamic_type_tag
                        < concrete_type >::tag ) );
                }

                // generate create functions taking any number of arguments
                #define BOOST_PP_LOCAL_LIMITS (1,                           \
                    BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
                #define BOOST_PP_LOCAL_MACRO(n)                             \
                template < BOOST_PP_ENUM_PARAMS(n, typename P) >            \
                pointer create (                                            \
                    BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )          \
                {                                                           \
                    return static_cast < pointer > (                        \
                        base_factory::create (                              \
                        ::boost::singleton::dynamic_type_tag                \
                        < concrete_type >::tag BOOST_PP_COMMA()             \
                        BOOST_PP_ENUM_PARAMS(n, p) ) );                     \
                }
                #include BOOST_PP_LOCAL_ITERATE()

                // overload taking a dynamic_type_tag as a first parameter
                template < typename Tag >
                pointer create ( const ::boost::singleton::dynamic_type_tag
                    < Tag > & )
                {
                    typedef typename MakeConcrete::make_concrete
                        < Tag >::type concrete_specified_type;
                    typedef typename Factory::factory
                        < Name, Tag >::pointer derived_pointer;
                    return static_cast < derived_pointer > (
                        base_factory::create (
                        ::boost::singleton::dynamic_type_tag
                        < concrete_specified_type >::tag ) );
                }

                // generate create function overloads taking
                // a dynamic_type_tag as a first parameter
                #define BOOST_PP_LOCAL_LIMITS (1,                           \
                    BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
                #define BOOST_PP_LOCAL_MACRO(n)                             \
                template < typename Tag,                                    \
                    BOOST_PP_ENUM_PARAMS(n, typename P) >                   \
                pointer create ( const ::boost::singleton::dynamic_type_tag \
                    < Tag > & BOOST_PP_COMMA()                              \
                    BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )          \
                {                                                           \
                    typedef typename MakeConcrete::make_concrete            \
                        < Tag >::type concrete_specified_type;              \
                    typedef typename Factory::factory                       \
                        < Name, Tag >::pointer derived_pointer;             \
                    return static_cast < derived_pointer > (                \
                        base_factory::create (                              \
                        ::boost::singleton::dynamic_type_tag                \
                        < concrete_specified_type >::tag BOOST_PP_COMMA()   \
                        BOOST_PP_ENUM_PARAMS(n, p) ) );                     \
                }
                #include BOOST_PP_LOCAL_ITERATE()

                void destroy ( pointer ptr )
                {
                    base_factory::destroy ( ptr );
                }
            };
        };

        // get access to indirect < hidden_type >
        template < typename Hidden >
        struct make_concrete_holder
        {
            template < typename AbstractType >
            struct make_concrete
            {
                // derive from abstract type and override
                // the pure virtual function
                struct type : public AbstractType
                {
                    virtual void make_abstract ( Hidden ) {  };

                    type (  )
                        : AbstractType (  ) {  }

                    // generate forwarding constructors
                    #define BOOST_PP_LOCAL_LIMITS (1,                       \
                        BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
                    #define BOOST_PP_LOCAL_MACRO(n)                         \
                    template < BOOST_PP_ENUM_PARAMS(n, typename P) >        \
                    type ( BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p) )   \
                    : AbstractType ( BOOST_PP_ENUM_PARAMS(n, p) ) {  }
                    #include BOOST_PP_LOCAL_ITERATE()
                };
            };
        };
    }

    template
    <
        typename Type,
        typename Factory
    >
    class uncreatable
    {
    private:
        // because hidden_type is private, derived classes cannot override
        // make_abstract, and thus are forced to be pure virtual
        struct hidden_type {  };
        // use indirect < hidden_type > to get past a bug in VC builds
        template < typename Internal > struct indirect {  };

        // makes this a pure virtual class
        virtual void make_abstract ( indirect < hidden_type > ) = 0;

    public:
        // singleton will be destroyed via a pointer to uncreatable
        // so this must be virtual
        virtual ~ uncreatable (  )
        {
        }

        // this type must be used as the singleton factory,
        // because it is the only type with creation permissions
        typedef typename ::boost::singleton::detail::uncreatable_factory
        <
            uncreatable < Type, Factory >,
            indirect < hidden_type >,
            Factory,
            ::boost::singleton::detail::
                make_concrete_holder < indirect < hidden_type > >

        > factory;
    };

    // for use with in_place_factory_ex
    struct uncreatable_in_place_size
    {
        template < typename Type >
        struct get_size
        {
            enum values
            {
                // assumes that the hidden type cannot possibly influence
                // the size of the concrete type, which only uses hidden
                // as a parameter of a member function
                value = sizeof ( typename ::boost::singleton::detail::
                    make_concrete_holder < char >::
                    make_concrete < Type >::type )
            };
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_UNCREATABLE_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
