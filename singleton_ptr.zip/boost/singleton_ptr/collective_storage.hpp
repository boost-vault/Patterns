
//////////////////////////////////////////////////////////////////////////////
// collective_storage.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.31.2005
// Purpose: Storage policy which groups policy instances and releases them
//          all at once, after all of their automated destroy mechanisms
//          have completed.  This makes phoenix creation of one singleton
//          by the destructor of another both safe and reliable.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_COLLECTIVE_STORAGE_INCLUDED_
#define BOOST_SINGLETON_PTR_COLLECTIVE_STORAGE_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <boost/aligned_storage.hpp>

namespace boost
{
    namespace singleton
    {
        namespace detail
        {
            // this must remain a POD type
            struct function_node
            {
                void ( *atomic_call )( void ( *call )(  ) );
                void ( *call )(  );
                function_node * next;
            };

            // adds a node to a static stack
            // add_node ( 0 ) triggers all functions and clears the stack
            void add_function_node ( function_node * n )
            {
                void ( *function )(  );
                void ( *atomic_call )( void ( *function )(  ) );

                static function_node * head ( 0 );

                if ( n )
                {
                    n->next = head;
                    head = n;
                }
                else
                {
                    while ( head )
                    {
                        function = head->call;
                        atomic_call = head->atomic_call;
                        head = head->next;
                        atomic_call ( function );
                    }
                }
            }

            struct terminator
            {
                // register function node stack for destruction
                static void init (  )
                {
                    static terminator t;
                }

                ~ terminator (  )
                {
                    // triggers function stack unwinding
                    add_function_node ( 0 );
                }
            };

            // forward declaration
            template < typename Type > void kill (  );

            // add a single Type instance to the stack if one has not
            // already been added, and return a pointer to it
            template < typename Type >
            Type * instance ( void ( *atomic_call )( void ( *call )(  ) ) )
            {
                // static storage for Type instance
                static typename::boost::aligned_storage
                    < sizeof ( Type ) >::type storage;

                static Type * inst (
                    reinterpret_cast < Type * > ( &storage ) );

                // the following block is executed only once
                // this block is not responsible for being thread safe, that
                // is handled further down via the atomic_call function
                static bool first = true;
                if ( first )
                {
                    // make sure that terminator is prepped to clear the stack
                    // of function_nodes at program termination
                    ::boost::singleton::detail::terminator::init (  );

                    // construct instance
                    new ( inst ) Type (  );

                    // register instance for destruction
                    static function_node n;
                    n.call = &::boost::singleton::detail::kill < Type >;
                    n.atomic_call = atomic_call;
                    add_function_node ( &n );
                    first = false;
                }

                return inst;
            }

            // destroy the single Type instance
            template < typename Type >
            void kill (  )
            {
                // because atomic_call has already been set, the function
                // pointer will not be used and can hence be null
                ::boost::singleton::detail::instance
                    < Type > ( 0 )->~Type (  );
            }
        }

        // Template for a lifetime policy.
        // One Accessor instance is created per process that accesses the
        // singleton, and the Accessor is destroyed when the process exits.
        // AtomicCall is used to make initialization and destruction of
        // the Accessor thread safe.
        template
        <
            typename Accessor,
            typename AtomicCall
        >
        struct collective_storage_ex
        {
            template
            <
                typename Name,
                typename Type
            >
            struct storage
            {
            public:
                typedef typename Accessor::
                        template accessor < Name, Type > accessor_type;

                typedef typename accessor_type::pointer pointer;

                typedef typename AtomicCall::
                        template atomic_call < Name, Type > atomic_call_type;

            private:
                // helper struct
                struct holder
                {
                    accessor_type accessor;
                    pointer ptr;

                    holder (  )
                        : accessor (  )
                        , ptr ( accessor.instance (  ) )
                    {
                    }
                };

                // get a reference to a static pointer
                // which points to the instance pointer
                // stored with the Accessor instance
                static pointer * & ppinst (  )
                {
                    static pointer * ptr;
                    return ptr;
                }

                // thread safe initialization of instance
                static void initialize (  )
                {
                    static holder * h ( ::boost::singleton::detail::instance
                        < holder > ( atomic_call_type::invoke ) );
                    ppinst (  ) = &h->ptr;
                }

            public:
                // get a pointer to the policy instance
                static pointer instance (  )
                {
                    atomic_call_type::invoke ( initialize );
                    return *ppinst (  );
                }
            };
        };

        // Accessor which stores the instance statically.
        struct simple_accessor
        {
            template
            <
                typename Name,
                typename Type
            >
            struct accessor
            {
                typedef Type * pointer;

                pointer instance (  )
                {
                    static Type inst;
                    return &inst;
                }
            };
        };

        // Useful only in single threaded contexts, does no locking.
        struct simple_atomic_call
        {
            template
            <
                typename Name,
                typename Type
            >
            struct atomic_call
            {
                static void invoke ( void ( *func )(  ) )
                {
                    func (  );
                }
            };
        };

        // Collective_storage makes dependencies between
        // singletons safe.  Use this policy when you have
        // complex interdependencies between singletons and
        // you want to ensure that any potential phoenix
        // creation at the time of program termination is
        // reliable and behaves naturally.
        typedef collective_storage_ex
        <
            simple_accessor,
            simple_atomic_call

        > collective_storage;
    }
}

#endif//BOOST_SINGLETON_PTR_COLLECTIVE_STORAGE_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
