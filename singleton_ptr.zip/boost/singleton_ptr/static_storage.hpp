
//////////////////////////////////////////////////////////////////////////////
// static_storage.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.31.2005
// Purpose: Simple, low overhead storage for singleton policies,
//          ideal for singletons which are not shared between threads
//          or processes, do not have complex linking requirements, and do
//          not require phoenix creation capability at program termination.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_STATIC_STORAGE_INCLUDED_
#define BOOST_SINGLETON_PTR_STATIC_STORAGE_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/aligned_storage.hpp>

namespace boost
{
    namespace singleton
    {
        // static_storage is the simplest storage mechanism,
        // requiring the least overhead.  Use this for simple
        // singletons that do not have dependencies on other
        // singletons, are not shared among multiple threads
        // or processes, and are not located within a dll.
        struct static_storage
        {
            template
            <
                typename Name,
                typename Type
            >
            struct storage
            {
                typedef Type * pointer;

                static pointer instance (  )
                {
                    static Type inst;
                    return &inst;
                }
            };
        };
    }
}

#endif//BOOST_SINGLETON_PTR_STATIC_STORAGE_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
