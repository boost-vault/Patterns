
//////////////////////////////////////////////////////////////////////////////
// single_threaded.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 07.08.2005
// Purpose: Single threaded threading policy for the singleton_ptr library.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_SINGLE_THREADED_INCLUDED_
#define BOOST_SINGLETON_PTR_SINGLE_THREADED_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <boost/singleton_ptr/config.hpp>

namespace boost { namespace singleton
{
    struct single_threaded
    {
        template
        <
            typename Name,
            typename Type,
            typename Creator
        >
        class threading
        {
        public:
            // internal policy types
            typedef Creator creator_type;
            typedef threading < Name, Type, Creator > threading_type;

            // dummy syncronization primitives
            typedef int mutex_type;
            typedef int read_lock_type;
            typedef int write_lock_type;

            // action function signature used for callbacks during
            // pointer creation and pointer dereferencing
            typedef bool ( *action_type )( creator_type * );

            // inner pointer types
            typedef typename
                creator_type::reference     inner_reference;
            typedef typename
                creator_type::pointer       inner_pointer;
            typedef typename
                creator_type::const_pointer inner_const_pointer;

        private:
            // member vars
            creator_type creator;
            mutex_type mux;

        public:
            struct reference
            {
            private:
                // member vars
                inner_reference inner;

            public:
                // must be provided with a pointer to the creator
                // and the actions to invoke upon creation and
                // dereferencing of the pointer
                reference ( threading_type * threading_ptr,
                            action_type on_creation,
                            action_type on_dereference )

                    : inner ( threading_ptr->get_creator (  ),
                                on_creation, on_dereference )
                {
                }

                operator Type & (  )
                {
                    return inner;
                }

                operator const Type & (  ) const
                {
                    return inner;
                }
            };

            // forward declaration
            struct const_pointer;

            struct pointer
            {
            private:
                // member vars
                threading_type * threading_ptr;
                inner_pointer inner;

            public:
                // must be provided with a pointer to the threading
                // policy and the actions to invoke upon creation and
                // dereferencing of the pointer
                pointer ( threading_type * threading_ptr,
                          action_type on_creation,
                          action_type on_dereference )

                    : threading_ptr ( threading_ptr )
                    , inner ( threading_ptr->get_creator (  ),
                                on_creation, on_dereference )
                {
                }

                const inner_pointer & operator -> (  ) const
                {
                    return inner;
                }

                // allow access to threading_ptr for implicit conversion
                friend struct const_pointer;
            };

            struct const_pointer
            {
            private:
                // member vars
                inner_const_pointer inner;

            public:
                const_pointer ( threading_type * const threading_ptr )
                    : inner ( threading_ptr->get_creator (  ) )

                {
                }

                // implicitly constructable from pointer
                const_pointer ( const pointer & ptr )
                    : inner ( ptr.threading_ptr->get_creator (  ) )

                {
                }

                const inner_const_pointer & operator -> (  ) const
                {
                    return inner;
                }
            };

            threading (  )
                : mux ( 0 )
            {
            }

            // get pointer to creator
            creator_type * get_creator (  )
            {
                return &creator;
            }

            // get const pointer to creator
            creator_type * const get_creator (  ) const
            {
                return &creator;
            }

            // access the mutex
            mutex_type & get_mutex (  )
            {
                return mux;
            }
        };
    };
} }

#endif//BOOST_SINGLETON_PTR_SINGLE_THREADED_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revision history:
//
//////////////////////////////////////////////////////////////////////////////
