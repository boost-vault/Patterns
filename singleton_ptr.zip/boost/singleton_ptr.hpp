
//////////////////////////////////////////////////////////////////////////////
// singleton_ptr.hpp
// copyright (c) Jason Hise, 2005
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
//  Author: Jason Hise
// Created: 08.03.2005
// Purpose: Provide policy based smart pointers to singleton resources.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef BOOST_SINGLETON_PTR_INCLUDED_
#define BOOST_SINGLETON_PTR_INCLUDED_

// MSVC optimization
#if ( defined _MSC_VER ) && ( _MSC_VER >= 1200 )
#  pragma once
#endif

#include <new>
#include <boost/aligned_storage.hpp>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>

#include <boost/singleton_ptr/detail/safe_bool.hpp>
#include <boost/singleton_ptr/policies.hpp>

namespace boost
{
    namespace singleton
    {
        namespace detail
        {
            template
            <
                typename Type,
                typename Storage,
                typename Lifetime,
                typename Actions
            >
            class singleton_impl
            {
            public:
                // actions
                typedef typename Actions::pointer_creation_action
                    pointer_creation_action;
                typedef typename Actions::pointer_dereferencing_action
                    pointer_dereferencing_action;

                // typedef all policy types
                typedef Storage  storage_type;
                typedef Lifetime lifetime_type;
                typedef typename lifetime_type::threading_type threading_type;
                typedef typename threading_type::creator_type creator_type;

                // typedef syncronization primitives
                typedef typename
                    threading_type::mutex_type mutex_type;
                typedef typename
                    threading_type::read_lock_type read_lock_type;
                typedef typename
                    threading_type::write_lock_type write_lock_type;

                // Smart pointer which always points to the current singleton
                // instance.  All operations performed on the singleton are
                // locked exclusively.
                class pointer : public ::boost::safe_bool < pointer >
                {
                private:
                    // helper struct to lock construction of
                    // a pointer and all of its members
                    struct lock_construction
                    {
                    private:
                        bool exists;
                        // storage for lock which we can
                        // construct and destruct in place
                        typename ::boost::aligned_storage
                            < sizeof ( write_lock_type ) >::type
                            lock_storage;

                        write_lock_type * lock_ptr;

                    public:
                        lock_construction ( mutex_type & mux )
                            : exists ( false )
                            , lock_ptr ( reinterpret_cast
                                < write_lock_type * > ( &lock_storage ) )
                        {
                            new ( lock_ptr ) write_lock_type ( mux );
                            exists = true;
                        }

                        // destroy the lock early
                        void unlock (  )
                        {
                            if ( exists )
                            {
                                lock_ptr->~write_lock_type (  );
                                exists = false;
                            }
                        }

                        ~ lock_construction (  )
                        {
                            // destroy the lock
                            if ( exists ) lock_ptr->~write_lock_type (  );
                        }
                    };

                    typedef typename storage_type::pointer policy_pointer;
                    typedef typename lifetime_type::pointer inner_pointer;

                    // pointer to policy bundle
                    policy_pointer policy_ptr;
                    // helper which serializes construction
                    lock_construction ctor_lock;
                    // internal pointer to singleton instance
                    inner_pointer inner_ptr;

                public:
                    // Construct pointer to instance, instantiating instances
                    // of the singleton policies in storage if they have not
                    // yet been created.  This operation acquires an exclusive
                    // lock before constructing internal objects, and releases
                    // the lock immediately before returning.
                    pointer (  )

                        : policy_ptr ( Storage::instance (  ) )
                        , ctor_lock ( policy_ptr->
                                      get_threading (  )->get_mutex (  ) )
                        , inner_ptr ( policy_ptr,
                                      pointer_creation_action::invoke,
                                      pointer_dereferencing_action::invoke )
                    {
                        // unlock after inner pointers have been instantiated
                        ctor_lock.unlock (  );
                    }

                    // Access a member of the singleton.  This operation is
                    // serialized with an exclusive lock.
                    const inner_pointer & operator -> (  ) const
                    {
                        return inner_ptr;
                    }

                    // Gets a raw reference to the instance.
                    Type & operator * (  ) const
                    {
                        return reference (  );
                    }

                    // Gets a raw pointer to the singleton instance.
                    Type * raw_pointer (  ) const
                    {
                        return &( this->operator * (  ) );
                    }

                    // Create the instance if it does not yet exist.
                    // This function can take any number of arguments, which
                    // are forwarded to the constructor.  If the first
                    // argument is of type dynamic_type_tag < D >, where D is
                    // a concrete child class of Type, and if the selected
                    // creator policy supports use of the tag, the singleton
                    // will be created as an instance of type D and the
                    // remaining arguments will be passed to D's constructor.
                    // If you use this tag to create the singleton as a
                    // derived type, the base singleton type must have a
                    // virtual destructor.
                    void create (  )
                    {
                        write_lock_type lock ( policy_ptr->
                            get_threading (  )->get_mutex (  ) );
                        ( void ) lock; // prevent unused variable warnings

                        // cast away volatile while lock is held
                        const_cast < creator_type * > (
                            policy_ptr->get_threading (  )->
                            get_creator (  ) )->create (  );
                    }

                    // generate create functions taking params
                    // that are passed to constructor
                    #define BOOST_PP_LOCAL_LIMITS (1,                       \
                        BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
                    #define BOOST_PP_LOCAL_MACRO(n)                         \
                    template < BOOST_PP_ENUM_PARAMS(n, typename P) >        \
                    void create (                                           \
                        BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p ) )     \
                    {                                                       \
                        write_lock_type lock ( policy_ptr->                 \
                            get_threading (  )->get_mutex (  ) );           \
                        ( void ) lock;                                      \
                        const_cast < creator_type * > (                     \
                        policy_ptr->get_threading (  )->                    \
                            get_creator (  ) )->create                      \
                            ( BOOST_PP_ENUM_PARAMS(n, p) );                 \
                    }
                    #include BOOST_PP_LOCAL_ITERATE()

                    // Destroy the instance if it exists.
                    void destroy (  )
                    {
                        write_lock_type lock ( policy_ptr->
                            get_threading (  )->get_mutex (  ) );
                        ( void ) lock; // prevent unused variable warnings

                        // const cast away volatile while we hold the lock
                        const_cast < creator_type * >
                        (
                            policy_ptr->get_threading (  )->
                            get_creator (  )

                        )->destroy (  );
                    }

                    // Explicitly check if the instance exists.
                    // Used by implicit safe_bool conversion.
                    // This function does not perform any locking, so client
                    // code should acquire a lock manually if necessary.
                    bool exists (  ) const
                    {
                        return const_cast < creator_type * > (
                            policy_ptr->get_threading (  )->
                            get_creator (  ) )->exists (  );
                    }
                };

                // Smart pointer which always points to the current singleton
                // instance, and which cannot modify the singleton's state.
                // Modification of state includes creation, destruction, and
                // access of non-const member functions.  Operations are
                // locked with a shared lock, which may or may not be the same
                // as an exclusive lock, depending on the threading policy
                // selected.
                class const_pointer :
                    public ::boost::safe_bool < const_pointer >
                {
                private:
                    // helper struct to lock construction of
                    // a const_pointer and all of its members
                    struct lock_construction
                    {
                    private:
                        bool exists;
                        // storage for lock which we can
                        // construct and destruct in place
                        typename ::boost::aligned_storage
                            < sizeof ( read_lock_type ) >::type
                            lock_storage;

                        read_lock_type * lock_ptr;

                    public:
                        lock_construction ( mutex_type & mux )
                            : exists ( false )
                            , lock_ptr ( reinterpret_cast
                                < read_lock_type * > ( &lock_storage ) )
                        {
                            new ( lock_ptr ) read_lock_type ( mux );
                            exists = true;
                        }

                        // destroy the lock early
                        void unlock (  )
                        {
                            if ( exists )
                            {
                                lock_ptr->~read_lock_type (  );
                                exists = false;
                            }
                        }

                        ~ lock_construction (  )
                        {
                            // destroy the lock
                            if ( exists ) lock_ptr->~read_lock_type (  );
                        }
                    };

                    typedef typename Storage::pointer policy_pointer;
                    typedef typename Lifetime::const_pointer inner_const_pointer;

                    // pointer to policy bundle
                    policy_pointer policy_ptr;
                    // helper which serializes construction
                    lock_construction ctor_lock;
                    // internal pointer to singleton instance
                    inner_const_pointer inner_const_ptr;

                public:
                    // Construct pointer to instance, instantiating instances
                    // of the singleton policies in storage if they have not
                    // yet been created.  This operation acquires a shared
                    // lock before constructing internal objects, and releases
                    // the lock immediately before returning.
                    const_pointer (  )

                        : policy_ptr ( Storage::instance (  ) )
                        , ctor_lock ( policy_ptr->
                                      get_threading (  )->get_mutex (  ) )
                        , inner_ptr ( policy_ptr )
                    {
                        // unlock after inner pointers have been instantiated
                        ctor_lock.unlock (  );
                    }

                    // Allow implicit conversion from pointer,
                    // same as default construction.
                    const_pointer ( const pointer & ptr )

                        : policy_ptr ( Storage::instance (  ) )
                        , ctor_lock ( policy_ptr->
                                      get_threading (  )->get_mutex (  ) )
                        , inner_ptr ( policy_ptr )
                    {
                        // unlock after inner pointers have been instantiated
                        ctor_lock.unlock (  );
                    }

                    // Access a member of the singleton.  This operation is
                    // serialized with a shared lock.
                    const inner_const_pointer & operator -> (  ) const
                    {
                        return inner_ptr;
                    }

                    // Get a raw const reference to the instance
                    const Type & operator * (  ) const
                    {
                        return reference (  );
                    }

                    // Get a raw pointer to const to the instance 
                    Type * const raw_pointer (  ) const
                    {
                        return &( this->operator * (  ) );
                    }

                    // Explicitly check if the instance exists.
                    // This is also required by safe_bool.
                    // This function does not perform any locking, so client
                    // code should acquire a lock manually if necessary.
                    bool exists (  ) const
                    {
                        return policy_ptr->get_threading (  )->
                            get_creator (  )->exists (  );
                    }
                };

                // Smart reference which always points to the current
                // singleton instance.  Holds an exclusive lock for its
                // entire lifetime.
                class reference
                {
                private:
                    typedef typename Storage::pointer policy_pointer;
                    typedef typename Lifetime::reference inner_reference;

                    // pointer to policy bundle
                    policy_pointer policy_ptr;
                    // own an exclusive lock
                    write_lock_type lock;
                    // internal pointer to singleton instance
                    inner_reference inner_ref;

                public:
                    // Acquires the exclusive lock before constructing
                    // any internal pointers.
                    reference (  )

                        : policy_ptr ( Storage::instance (  ) )
                        , lock ( policy_ptr->
                                 get_threading (  )->get_mutex (  ) )
                        , inner_ref ( policy_ptr,
                                      pointer_creation_action::invoke,
                                      pointer_dereferencing_action::invoke )
                    {
                    }

                    // Dereference the singleton instance
                    operator Type & (  )
                    {
                        return inner_ref;
                    }

                    // Dereference a const reference to the singleton instance
                    operator const Type & (  ) const
                    {
                        return inner_ref;
                    }

                    // Create the instance if it does not yet exist.
                    // This function can take any number of arguments, which
                    // are forwarded to the constructor.  If the first
                    // argument is of type dynamic_type_tag < D >, where D is
                    // a concrete child class of Type, and if the selected
                    // creator policy supports use of the tag, the singleton
                    // will be created as an instance of type D and the
                    // remaining arguments will be passed to D's constructor.
                    // If you use this tag to create the singleton as a
                    // derived type, the base singleton type must have a
                    // virtual destructor.
                    void create (  )
                    {
                        policy_ptr->get_threading (  )->
                            get_creator (  )->create (  );
                            
                    }

                    // generate create functions taking params
                    // that are passed to constructor
                    #define BOOST_PP_LOCAL_LIMITS (1,                       \
                        BOOST_SINGLETON_PTR_MAX_CONSTRUCTOR_PARAMS)
                    #define BOOST_PP_LOCAL_MACRO(n)                         \
                    template < BOOST_PP_ENUM_PARAMS(n, typename P) >        \
                    void create (                                           \
                        BOOST_PP_ENUM_BINARY_PARAMS(n, const P, & p ) )     \
                    {                                                       \
                        write_lock_type lock ( policy_ptr->                 \
                            get_threading (  )->get_mutex (  ) );           \
                        ( void ) lock;                                      \
                        policy_ptr->get_threading (  )->                    \
                            get_creator (  )->create                        \
                            ( BOOST_PP_ENUM_PARAMS(n, p) );                 \
                    }
                    #include BOOST_PP_LOCAL_ITERATE()

                    // Destroy the instance if it exists.
                    void destroy (  )
                    {
                        policy_ptr->get_threading (  )->
                            get_creator (  )->destroy (  );
                    }

                    // Explicitly check if the instance exists.
                    bool exists (  ) const
                    {
                        return policy_ptr->get_threading (  )->
                            get_creator (  )->exists (  );
                    }
                };
            };

            template
            <
                typename PointerCreation,
                typename PointerDereferencing
            >
            struct action_types
            {
                typedef PointerCreation      pointer_creation_action;
                typedef PointerDereferencing pointer_dereferencing_action;
            };

            template
            <
                typename Type,
                typename Policy0,
                typename Policy1,
                typename Policy2,
                typename Policy3,
                typename Policy4,
                typename Policy5,
                typename Policy6
            >
            struct policy_singleton
                : public virtual ::boost::singleton::policy_setter
                // there are enough slots to specify (in any order):
                , public Policy0 // name
                , public Policy1 // creator
                , public Policy2 // lifetime
                , public Policy3 // threading
                , public Policy4 // storage
                , public Policy5 // on_creation
                , public Policy6 // on_dereference
            {
            private:
                typedef Type instance_type;

                typedef ::boost::singleton::detail::action_types
                <
                    pointer_creation_action,
                    pointer_dereferencing_action

                > action_types;

                typedef creator_policy::creator
                <
                    instance_name,
                    instance_type

                > creator_type;

                typedef threading_policy::threading
                <
                    instance_name,
                    instance_type,
                    creator_type

                > threading_type;

                typedef lifetime_policy::lifetime
                <
                    instance_name,
                    instance_type,
                    threading_type

                > lifetime_type;

                typedef typename storage_policy::storage
                <
                    instance_name,
                    lifetime_type

                > storage_type;

            public:
                typedef ::boost::singleton::detail::singleton_impl
                <
                    instance_type,
                    storage_type,
                    lifetime_type,
                    action_types

                > type;
            };
        }
    }

    template
    <
        typename Type,
        typename Policy0 = singleton::default_policy,
        typename Policy1 = singleton::default_policy,
        typename Policy2 = singleton::default_policy,
        typename Policy3 = singleton::default_policy,
        typename Policy4 = singleton::default_policy,
        typename Policy5 = singleton::default_policy,
        typename Policy6 = singleton::default_policy
    >
    struct singleton_holder : public
        ::boost::singleton::detail::policy_singleton
    <
        Type,
        Policy0,
        Policy1,
        Policy2,
        Policy3,
        Policy4,
        Policy5,
        Policy6

    > ::type {  };

    template
    <
        typename Type,
        typename Policy0 = singleton::default_policy,
        typename Policy1 = singleton::default_policy,
        typename Policy2 = singleton::default_policy,
        typename Policy3 = singleton::default_policy,
        typename Policy4 = singleton::default_policy,
        typename Policy5 = singleton::default_policy,
        typename Policy6 = singleton::default_policy
    >
    struct singleton_ptr : public ::boost::singleton_holder
    <
        Type,
        Policy0,
        Policy1,
        Policy2,
        Policy3,
        Policy4,
        Policy5,
        Policy6

    > ::pointer {  };

    template
    <
        typename Type,
        typename Policy0 = singleton::default_policy,
        typename Policy1 = singleton::default_policy,
        typename Policy2 = singleton::default_policy,
        typename Policy3 = singleton::default_policy,
        typename Policy4 = singleton::default_policy,
        typename Policy5 = singleton::default_policy,
        typename Policy6 = singleton::default_policy
    >
    struct const_singleton_ptr : public ::boost::singleton_holder
    <
        Type,
        Policy0,
        Policy1,
        Policy2,
        Policy3,
        Policy4,
        Policy5,
        Policy6

    > ::const_pointer {  };

    template
    <
        typename Type,
        typename Policy0 = singleton::default_policy,
        typename Policy1 = singleton::default_policy,
        typename Policy2 = singleton::default_policy,
        typename Policy3 = singleton::default_policy,
        typename Policy4 = singleton::default_policy,
        typename Policy5 = singleton::default_policy,
        typename Policy6 = singleton::default_policy
    >
    struct singleton_ref : public ::boost::singleton_holder
    <
        Type,
        Policy0,
        Policy1,
        Policy2,
        Policy3,
        Policy4,
        Policy5,
        Policy6

    > ::reference {  };
}

#endif//BOOST_SINGLETON_PTR_INCLUDED_

//////////////////////////////////////////////////////////////////////////////
// Revised: <never>
//
//////////////////////////////////////////////////////////////////////////////
