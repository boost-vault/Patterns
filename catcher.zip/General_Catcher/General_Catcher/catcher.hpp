///////////////////////////////////////////////////////////////////////////////
/// \file General_Catcher.cpp
/// 
/// \brief Implementation for Boost Catcher.
/// 
/// Copyright Jeremy Day 2006
/// 
/// Distributed under the Boost Software License, Version 1.0. 
/// (See accompanying file LICENSE_1_0.txt or copy at 
/// http://www.boost.org/LICENSE_1_0.txt)
/// 
/// \date 07.27.06
///////////////////////////////////////////////////////////////////////////////
#ifndef _CATCHER_HPP_
#define _CATCHER_HPP_
#include <boost/mpl/begin.hpp>
#include <boost/mpl/deref.hpp>
#include <boost/mpl/not.hpp>
#include <boost/mpl/sort.hpp>
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/is_base_of.hpp>

template <bool done = true>
struct catcher_while_impl
	{
	template <typename Iterator, typename LastIterator, typename F>
	static void execute(Iterator*, LastIterator*, F f)
		{
		//Call the default exception handler provided by the user-provided exception handling class.
		f();
		} //end of static void execute(Iterator*, LastIterator*, F f)
	}; //end of struct catcher_while_impl

template <>
struct catcher_while_impl<false>
	{
	template <typename Iterator, typename LastIterator, typename F>
	static void execute(Iterator*, LastIterator*, F f)
		{
		typedef typename boost::mpl::deref<Iterator>::type item;

		try
			{
			throw;
			} //end of try block
		catch(boost::add_reference<item>::type oError)
			{
			f(oError);
			} //end of catch(boost::add_reference<boost::mpl::deref<MPLForwardIterator>::type>::type oError) block
		catch(...)
			{
			//Get the next item from the exceptions sequence.
			typedef typename boost::mpl::next<Iterator>::type iter;

			catcher_while_impl<boost::is_same<iter, LastIterator>::value>::execute((iter*)0, (LastIterator*)0, f);
			} //end of catch(...) block
		} //end of static void execute(Iterator*, LastIterator*, F f)
	}; //end of struct catcher_while_impl<false>

template <typename Sequence, typename F>
inline void catcher_while_(F f, Sequence* = 0)
	{
	//Sort the exceptions so that the most-derived exceptions are first in the list.
	typedef boost::mpl::sort<
		Sequence
		, boost::mpl::not_<
			boost::is_base_of<
				boost::mpl::_
				, boost::mpl::_
				>
			>
		>::type sorted_sequence;
	typedef typename boost::mpl::begin<sorted_sequence>::type first;
	typedef typename boost::mpl::end<sorted_sequence>::type last;

	catcher_while_impl<boost::is_same<first, last>::value>::execute((first*)0, (last*)0, f);
	} //end of inline void catcher_while_loop(F f, Sequence* = 0)

template <typename ExceptionHandler>
void catcher(ExceptionHandler& oHandler)
	{
	catcher_while_<ExceptionHandler::exceptions>(oHandler);
	} //end of void catcher(void)

template <typename Exceptions, typename ExceptionHandler>
void catcher(ExceptionHandler& oHandler)
	{
	catcher_while_<Exceptions>(oHandler);
	} //end of void catcher(ExceptionHandler& oHandler)

#define BOOST_CATCH(handler)				\
catch(...)									\
	{										\
	catcher(handler);						\
	}

#define BOOST_CATCH_EX(exceptions, handler)	\
catch(...)									\
	{										\
	catcher<exceptions>(handler);			\
	}

#endif //end of #ifndef _CATCHER_HPP_
