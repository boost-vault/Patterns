///////////////////////////////////////////////////////////////////////////////
/// \file General_Catcher.cpp
/// 
/// \brief Basic demonstration of Boost Catcher.
/// 
/// Copyright Jeremy Day 2006
/// 
/// Distributed under the Boost Software License, Version 1.0. 
/// (See accompanying file LICENSE_1_0.txt or copy at 
/// http://www.boost.org/LICENSE_1_0.txt)
/// 
/// \date 07.27.06
///////////////////////////////////////////////////////////////////////////////
#include "catcher.hpp"
#include <iostream>
#include <boost/mpl/vector.hpp>

struct my_exception_handler
	{
	typedef boost::mpl::vector<std::logic_error, std::exception> exceptions;

	void operator()(std::exception& oError)
		{
		std::cout << "my_exception_handler::operator()(std::exception&)" << std::endl;
		} //end of void operator()(std::exception& oError)

	void operator()(std::logic_error& oError)
		{
		std::cout << "my_exception_handler::operator()(std::logic_error&)" << std::endl;
		} //end of void operator()(std::logic_error& oError)

	void operator()(void)
		{
		std::cout << "my_exception_handler::operator()(void)" << std::endl;
		} //end of void operator()(void)
	}; //end of struct my_exception_handler

struct my_exception_handler2
	{
	void operator()(std::exception& oError)
		{
		std::cout << "my_exception_handler2::operator()(std::exception&)" << std::endl;
		} //end of void operator()(std::exception& oError)

	void operator()(std::logic_error& oError)
		{
		std::cout << "my_exception_handler2::operator()(std::logic_error&)" << std::endl;
		} //end of void operator()(std::logic_error& oError)

	void operator()(void)
		{
		std::cout << "my_exception_handler2::operator()(void)" << std::endl;
		} //end of void operator()(void)
	}; //end of struct my_exception_handler

int main(int argc, char* argv[])
	{
	try
		{
		throw(std::logic_error("testing"));
		} //end of try block
	BOOST_CATCH(my_exception_handler())

	try
		{
		throw(std::exception("testing"));
		} //end of try block
	BOOST_CATCH(my_exception_handler())

	try
		{
		throw("testing");
		} //end of try block
	BOOST_CATCH(my_exception_handler())

	std::cout << std::endl;

	typedef boost::mpl::vector<std::exception, std::logic_error> exceptions;

	try
		{
		throw(std::logic_error("testing"));
		} //end of try block
	BOOST_CATCH_EX(exceptions, my_exception_handler2());

	try
		{
		throw(std::exception("testing"));
		} //end of try block
	BOOST_CATCH_EX(exceptions, my_exception_handler2());

	try
		{
		throw("testing");
		} //end of try block
	BOOST_CATCH_EX(exceptions, my_exception_handler2());

	std::cout << std::endl;

	return(0);
	} //end of int main(int argc, char* argv[])

